/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
// tr_shade.c

#include "tr_local.h"

/*

  THIS ENTIRE FILE IS BACK END

  This file deals with applying shaders to surface data in the tess struct.
*/

/*
==================
R_DrawElements

==================
*/

void R_DrawElements(int numIndexes, int firstIndex) {
	if(tess.useCacheVao) {
		VaoCache_DrawElements(numIndexes, firstIndex);
	} else {
		qglDrawElements(GL_TRIANGLES, numIndexes, GL_INDEX_TYPE, BUFFER_OFFSET(firstIndex * sizeof(glIndex_t)));
	}
}

/*
=============================================================

SURFACE SHADERS

=============================================================
*/

shaderCommands_t tess;

/*
=================
R_BindAnimatedImageToTMU

=================
*/
static void R_BindAnimatedImageToTMU(textureBundle_t* bundle, int tmu) {
	int64_t index;

	if(bundle->isVideoMap) {
		ri.CIN_RunCinematic(bundle->videoMapHandle);
		ri.CIN_UploadCinematic(bundle->videoMapHandle);
		GL_BindToTMU(tr.scratchImage[bundle->videoMapHandle], tmu);
		return;
	}

	if(bundle->numImageAnimations <= 1) {
		GL_BindToTMU(bundle->image[0], tmu);
		return;
	}

	// it is necessary to do this messy calc to make sure animations line up
	// exactly with waveforms of the same frequency
	index = tess.shaderTime * bundle->imageAnimationSpeed * FUNCTABLE_SIZE;
	index >>= FUNCTABLE_SIZE2;

	if(index < 0) {
		index = 0;  // may happen with shader time offsets
	}

	// Windows x86 doesn't load renderer DLL with 64 bit modulus
	// index %= bundle->numImageAnimations;
	while(index >= bundle->numImageAnimations) {
		index -= bundle->numImageAnimations;
	}

	GL_BindToTMU(bundle->image[index], tmu);
}

/*
================
DrawTris

Draws triangle outlines for debugging
================
*/
static void DrawTris(shaderCommands_t* input) {
	GL_BindToTMU(tr.whiteImage, TB_COLORMAP);

	GL_State(GLS_POLYMODE_LINE | GLS_DEPTHMASK_TRUE);
	qglDepthRange(0, 0);

	{
		shaderProgram_t* sp = &tr.textureColorShader;
		vec4_t color;

		GLSL_BindProgram(sp);

		GLSL_SetUniformMat4(sp, UNIFORM_MODELVIEWPROJECTIONMATRIX, glState.modelviewProjection);
		VectorSet4(color, 1, 1, 1, 1);
		GLSL_SetUniformVec4(sp, UNIFORM_COLOR, color);
		GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, 0);

		R_DrawElements(input->numIndexes, input->firstIndex);
	}

	qglDepthRange(0, 1);
}

/*
==============
RB_BeginSurface

We must set some things up before beginning any tesselation,
because a surface may be forced to perform a RB_End due
to overflow.
==============
*/
void RB_BeginSurface(shader_t* shader, int fogNum, bool useCubemap, const vec3_t cubemapOrigin, const float cubemapBound) {
	shader_t* state = (shader->remappedShader) ? shader->remappedShader : shader;

	tess.numIndexes = 0;
	tess.firstIndex = 0;
	tess.numVertexes = 0;
	tess.shader = state;
	tess.fogNum = fogNum;
	tess.useCubemap = useCubemap;
	VectorCopy(cubemapOrigin, tess.cubemapOrigin);
	tess.cubemapBound = cubemapBound;
	tess.dlightBits = 0;  // will be OR'd in by surface functions
	tess.xstages = state->stages;
	tess.numPasses = state->numUnfoggedPasses;
	tess.currentStageIteratorFunc = state->optimalStageIteratorFunc;
	tess.useInternalVao = true;
	tess.useCacheVao = false;

	tess.shaderTime = backEnd.refdef.floatTime - tess.shader->timeOffset;
	if(tess.shader->clampTime && tess.shaderTime >= tess.shader->clampTime) {
		tess.shaderTime = tess.shader->clampTime;
	}

	if(backEnd.currentEntity && backEnd.currentEntity != &tr.worldEntity && backEnd.currentEntity->needDlights) {
		tess.dlightBits |= backEnd.currentEntity->needDlights;
	}

	if(backEnd.viewParms.flags & VPF_SHADOWMAP) {
		tess.currentStageIteratorFunc = RB_StageIteratorGeneric;
	}
}

extern float EvalWaveForm(const waveForm_t* wf);
extern float EvalWaveFormClamped(const waveForm_t* wf);

static void ComputeTexMods(shaderStage_t* pStage, int bundleNum, vec4_t outMatrix[8]) {
	int tm;
	float matrix[6];
	float tmpmatrix[6];
	float currentmatrix[6];
	float turb[2];
	textureBundle_t* bundle = &pStage->bundle[bundleNum];
	bool hasTurb = false;

	currentmatrix[0] = 1.0f;
	currentmatrix[2] = 0.0f;
	currentmatrix[4] = 0.0f;
	currentmatrix[1] = 0.0f;
	currentmatrix[3] = 1.0f;
	currentmatrix[5] = 0.0f;

	for(tm = 0; tm < bundle->numTexMods; tm++) {
		switch(bundle->texMods[tm].type) {
			case TMOD_NONE:
				matrix[0] = 1.0f;
				matrix[2] = 0.0f;
				matrix[4] = 0.0f;
				matrix[1] = 0.0f;
				matrix[3] = 1.0f;
				matrix[5] = 0.0f;
				break;

			case TMOD_TURBULENT: RB_CalcTurbulentFactors(&bundle->texMods[tm].wave, &turb[0], &turb[1]); break;

			case TMOD_ENTITY_TRANSLATE: RB_CalcScrollTexMatrix(backEnd.currentEntity->e.shaderTexCoord, matrix); break;

			case TMOD_SCROLL: RB_CalcScrollTexMatrix(bundle->texMods[tm].scroll, matrix); break;

			case TMOD_SCALE: RB_CalcScaleTexMatrix(bundle->texMods[tm].scale, matrix); break;

			case TMOD_STRETCH: RB_CalcStretchTexMatrix(&bundle->texMods[tm].wave, matrix); break;

			case TMOD_TRANSFORM: RB_CalcTransformTexMatrix(&bundle->texMods[tm], matrix); break;

			case TMOD_ROTATE: RB_CalcRotateTexMatrix(bundle->texMods[tm].rotateSpeed, matrix); break;

			default: ri.Error(ERR_DROP, "ERROR: unknown texmod '%d' in shader '%s'", bundle->texMods[tm].type, tess.shader->name); break;
		}

		switch(bundle->texMods[tm].type) {
			case TMOD_TURBULENT:
				outMatrix[tm * 2 + 0][0] = 1;
				outMatrix[tm * 2 + 0][1] = 0;
				outMatrix[tm * 2 + 0][2] = 0;
				outMatrix[tm * 2 + 1][0] = 0;
				outMatrix[tm * 2 + 1][1] = 1;
				outMatrix[tm * 2 + 1][2] = 0;

				outMatrix[tm * 2 + 0][3] = turb[0];
				outMatrix[tm * 2 + 1][3] = turb[1];

				hasTurb = true;
				break;

			case TMOD_NONE:
			case TMOD_ENTITY_TRANSLATE:
			case TMOD_SCROLL:
			case TMOD_SCALE:
			case TMOD_STRETCH:
			case TMOD_TRANSFORM:
			case TMOD_ROTATE:
			default:
				outMatrix[tm * 2 + 0][0] = matrix[0];
				outMatrix[tm * 2 + 0][1] = matrix[2];
				outMatrix[tm * 2 + 0][2] = matrix[4];
				outMatrix[tm * 2 + 1][0] = matrix[1];
				outMatrix[tm * 2 + 1][1] = matrix[3];
				outMatrix[tm * 2 + 1][2] = matrix[5];

				outMatrix[tm * 2 + 0][3] = 0;
				outMatrix[tm * 2 + 1][3] = 0;

				tmpmatrix[0] = matrix[0] * currentmatrix[0] + matrix[2] * currentmatrix[1];
				tmpmatrix[1] = matrix[1] * currentmatrix[0] + matrix[3] * currentmatrix[1];

				tmpmatrix[2] = matrix[0] * currentmatrix[2] + matrix[2] * currentmatrix[3];
				tmpmatrix[3] = matrix[1] * currentmatrix[2] + matrix[3] * currentmatrix[3];

				tmpmatrix[4] = matrix[0] * currentmatrix[4] + matrix[2] * currentmatrix[5] + matrix[4];
				tmpmatrix[5] = matrix[1] * currentmatrix[4] + matrix[3] * currentmatrix[5] + matrix[5];

				currentmatrix[0] = tmpmatrix[0];
				currentmatrix[1] = tmpmatrix[1];
				currentmatrix[2] = tmpmatrix[2];
				currentmatrix[3] = tmpmatrix[3];
				currentmatrix[4] = tmpmatrix[4];
				currentmatrix[5] = tmpmatrix[5];
				break;
		}
	}

	// if turb isn't used, only one matrix is needed
	if(!hasTurb) {
		tm = 0;

		outMatrix[tm * 2 + 0][0] = currentmatrix[0];
		outMatrix[tm * 2 + 0][1] = currentmatrix[2];
		outMatrix[tm * 2 + 0][2] = currentmatrix[4];
		outMatrix[tm * 2 + 1][0] = currentmatrix[1];
		outMatrix[tm * 2 + 1][1] = currentmatrix[3];
		outMatrix[tm * 2 + 1][2] = currentmatrix[5];

		outMatrix[tm * 2 + 0][3] = 0;
		outMatrix[tm * 2 + 1][3] = 0;
		tm++;
	}

	for(; tm < TR_MAX_TEXMODS; tm++) {
		outMatrix[tm * 2 + 0][0] = 1;
		outMatrix[tm * 2 + 0][1] = 0;
		outMatrix[tm * 2 + 0][2] = 0;
		outMatrix[tm * 2 + 1][0] = 0;
		outMatrix[tm * 2 + 1][1] = 1;
		outMatrix[tm * 2 + 1][2] = 0;

		outMatrix[tm * 2 + 0][3] = 0;
		outMatrix[tm * 2 + 1][3] = 0;
	}
}

static void ComputeDeformValues(int* deformGen, vec5_t deformParams) {
	// u_DeformGen
	*deformGen = DGEN_NONE;
	if(!ShaderRequiresCPUDeforms(tess.shader)) {
		deformStage_t* ds;

		// only support the first one
		ds = &tess.shader->deforms[0];

		switch(ds->deformation) {
			case DEFORM_WAVE:
				*deformGen = ds->deformationWave.func;

				deformParams[0] = ds->deformationWave.base;
				deformParams[1] = ds->deformationWave.amplitude;
				deformParams[2] = ds->deformationWave.phase;
				deformParams[3] = ds->deformationWave.frequency;
				deformParams[4] = ds->deformationSpread;
				break;

			case DEFORM_BULGE:
				*deformGen = DGEN_BULGE;

				deformParams[0] = 0;
				deformParams[1] = ds->bulgeHeight;  // amplitude
				deformParams[2] = ds->bulgeWidth;   // phase
				deformParams[3] = ds->bulgeSpeed;   // frequency
				deformParams[4] = 0;
				break;

			default: break;
		}
	}
}

static void ComputeShaderColors(shaderStage_t* pStage, vec4_t baseColor, vec4_t vertColor, int blend) {
	bool isBlend = ((blend & GLS_SRCBLEND_BITS) == GLS_SRCBLEND_DST_COLOR) || ((blend & GLS_SRCBLEND_BITS) == GLS_SRCBLEND_ONE_MINUS_DST_COLOR) || ((blend & GLS_DSTBLEND_BITS) == GLS_DSTBLEND_SRC_COLOR) || ((blend & GLS_DSTBLEND_BITS) == GLS_DSTBLEND_ONE_MINUS_SRC_COLOR);

	bool is2DDraw = backEnd.currentEntity == &backEnd.entity2D;

	float overbright = (isBlend || is2DDraw) ? 1.0f : (float)(1 << tr.overbrightBits);

	fog_t* fog;

	baseColor[0] = baseColor[1] = baseColor[2] = baseColor[3] = 1.0f;

	vertColor[0] = vertColor[1] = vertColor[2] = vertColor[3] = 0.0f;

	//
	// rgbGen
	//
	switch(pStage->rgbGen) {
		case CGEN_EXACT_VERTEX:
		case CGEN_EXACT_VERTEX_LIT:
			baseColor[0] = baseColor[1] = baseColor[2] = baseColor[3] = 0.0f;

			vertColor[0] = vertColor[1] = vertColor[2] = overbright;
			vertColor[3] = 1.0f;
			break;
		case CGEN_CONST:
			baseColor[0] = pStage->constantColor[0] / 255.0f;
			baseColor[1] = pStage->constantColor[1] / 255.0f;
			baseColor[2] = pStage->constantColor[2] / 255.0f;
			baseColor[3] = pStage->constantColor[3] / 255.0f;
			break;
		case CGEN_VERTEX:
		case CGEN_VERTEX_LIT:
			baseColor[0] = baseColor[1] = baseColor[2] = baseColor[3] = 0.0f;

			vertColor[0] = vertColor[1] = vertColor[2] = vertColor[3] = 1.0f;
			break;
		case CGEN_ONE_MINUS_VERTEX:
			baseColor[0] = baseColor[1] = baseColor[2] = 1.0f;

			vertColor[0] = vertColor[1] = vertColor[2] = -1.0f;
			break;
		case CGEN_FOG:
			fog = tr.world->fogs + tess.fogNum;

			baseColor[0] = ((unsigned char*)(&fog->colorInt))[0] / 255.0f;
			baseColor[1] = ((unsigned char*)(&fog->colorInt))[1] / 255.0f;
			baseColor[2] = ((unsigned char*)(&fog->colorInt))[2] / 255.0f;
			baseColor[3] = ((unsigned char*)(&fog->colorInt))[3] / 255.0f;
			break;
		case CGEN_WAVEFORM: baseColor[0] = baseColor[1] = baseColor[2] = RB_CalcWaveColorSingle(&pStage->rgbWave); break;
		case CGEN_COLOR_WAVEFORM: {
			float glow = RB_CalcWaveColorSingle(&pStage->rgbWave);

			baseColor[0] = glow * pStage->constantColor[0] / 255.0f;
			baseColor[1] = glow * pStage->constantColor[1] / 255.0f;
			baseColor[2] = glow * pStage->constantColor[2] / 255.0f;
		} break;
		case CGEN_ENTITY:
			if(backEnd.currentEntity) {
				baseColor[0] = ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[0] / 255.0f;
				baseColor[1] = ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[1] / 255.0f;
				baseColor[2] = ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[2] / 255.0f;
				baseColor[3] = ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[3] / 255.0f;
			}
			break;
		case CGEN_ONE_MINUS_ENTITY:
			if(backEnd.currentEntity) {
				baseColor[0] = 1.0f - ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[0] / 255.0f;
				baseColor[1] = 1.0f - ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[1] / 255.0f;
				baseColor[2] = 1.0f - ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[2] / 255.0f;
				baseColor[3] = 1.0f - ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[3] / 255.0f;
			}
			break;
		case CGEN_IDENTITY:
		case CGEN_LIGHTING_DIFFUSE:
		case CGEN_LIGHTING_DIFFUSE_ENTITY: baseColor[0] = baseColor[1] = baseColor[2] = overbright; break;
		case CGEN_IDENTITY_LIGHTING:
		case CGEN_BAD: break;
	}

	//
	// alphaGen
	//
	switch(pStage->alphaGen) {
		case AGEN_SKIP: break;
		case AGEN_CONST:
			baseColor[3] = pStage->constantColor[3] / 255.0f;
			vertColor[3] = 0.0f;
			break;
		case AGEN_WAVEFORM:
			baseColor[3] = RB_CalcWaveAlphaSingle(&pStage->alphaWave);
			vertColor[3] = 0.0f;
			break;
		case AGEN_ENTITY:
			if(backEnd.currentEntity) {
				baseColor[3] = ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[3] / 255.0f;
			}
			vertColor[3] = 0.0f;
			break;
		case AGEN_ONE_MINUS_ENTITY:
			if(backEnd.currentEntity) {
				baseColor[3] = 1.0f - ((unsigned char*)backEnd.currentEntity->e.shaderRGBA)[3] / 255.0f;
			}
			vertColor[3] = 0.0f;
			break;
		case AGEN_VERTEX:
			baseColor[3] = 0.0f;
			vertColor[3] = 1.0f;
			break;
		case AGEN_ONE_MINUS_VERTEX:
			baseColor[3] = 1.0f;
			vertColor[3] = -1.0f;
			break;
		case AGEN_IDENTITY:
		case AGEN_LIGHTING_SPECULAR:
		case AGEN_PORTAL:
			// Done entirely in vertex program
			baseColor[3] = 1.0f;
			vertColor[3] = 0.0f;
			break;
	}
}

static void ComputeFogValues(vec4_t fogDistanceVector, vec4_t fogDepthVector, float* eyeT) {
	// from RB_CalcFogTexCoords()
	fog_t* fog;
	vec3_t local;

	if(!tess.fogNum) return;

	fog = tr.world->fogs + tess.fogNum;

	VectorSubtract(backEnd.or.origin, backEnd.viewParms.or.origin, local);
	fogDistanceVector[0] = -backEnd.or.modelMatrix[2];
	fogDistanceVector[1] = -backEnd.or.modelMatrix[6];
	fogDistanceVector[2] = -backEnd.or.modelMatrix[10];
	fogDistanceVector[3] = DotProduct(local, backEnd.viewParms.or.axis[0]);

	// scale the fog vectors based on the fog's thickness
	VectorScale4(fogDistanceVector, fog->tcScale, fogDistanceVector);

	// rotate the gradient vector for this orientation
	if(fog->hasSurface) {
		fogDepthVector[0] = fog->surface[0] * backEnd.or.axis[0][0] + fog->surface[1] * backEnd.or.axis[0][1] + fog->surface[2] * backEnd.or.axis[0][2];
		fogDepthVector[1] = fog->surface[0] * backEnd.or.axis[1][0] + fog->surface[1] * backEnd.or.axis[1][1] + fog->surface[2] * backEnd.or.axis[1][2];
		fogDepthVector[2] = fog->surface[0] * backEnd.or.axis[2][0] + fog->surface[1] * backEnd.or.axis[2][1] + fog->surface[2] * backEnd.or.axis[2][2];
		fogDepthVector[3] = -fog->surface[3] + DotProduct(backEnd.or.origin, fog->surface);

		*eyeT = DotProduct(backEnd.or.viewOrigin, fogDepthVector) + fogDepthVector[3];
	} else {
		*eyeT = 1;  // non-surface fog always has eye inside
	}
}

static void ForwardDlightEnt(shaderStage_t* pStage) {
	int l;
	float radius;
	float intensity;

	int deformGen;
	vec5_t deformParams;

	vec4_t fogDistanceVector, fogDepthVector = {0, 0, 0, 0};
	float eyeT = 0;

	shaderCommands_t* input = &tess;

	if(!backEnd.refdef.num_dlights || !pStage) {
		return;
	}

	ComputeDeformValues(&deformGen, deformParams);
	ComputeFogValues(fogDistanceVector, fogDepthVector, &eyeT);

	for(l = 0; l < backEnd.refdef.num_dlights; l++) {
		dlight_t* dl;
		shaderProgram_t* sp;
		vec4_t vector;
		vec4_t texMatrix[8];
		int index;

		if(!(tess.dlightBits & (1 << l))) {
			continue;
		}

		dl = &backEnd.refdef.dlights[l];

		radius = dl->radius;
		intensity = Com_Clamp(0.0f, 1.0f, dl->intensity);

		if(pStage->glslShaderGroup == tr.lightallShader) {
			index = pStage->glslShaderIndex;

			index &= ~LIGHTDEF_LIGHTTYPE_MASK;
			index |= LIGHTDEF_USE_LIGHT_VECTOR;
		} else {
			index = LIGHTDEF_USE_LIGHT_VECTOR;

			if(pStage->bundle[0].tcGen != TCGEN_TEXTURE || pStage->bundle[0].numTexMods != 0) {
				index |= LIGHTDEF_USE_TCGEN_AND_TCMOD;
			}
		}

		/*
		 * Entity rendering needs the model transform in the
		 * lightall vertex shader.
		 */
		if(backEnd.currentEntity && backEnd.currentEntity != &tr.worldEntity) {
			if(glState.boneAnimation) {
				index |= LIGHTDEF_ENTITY_BONE_ANIMATION;
			} else {
				/*
				 * This flag also enables USE_MODELMATRIX.
				 * A static entity still needs the model matrix even
				 * when vertex animation itself is disabled.
				 */
				index |= LIGHTDEF_ENTITY_VERTEX_ANIMATION;
			}
		}

		sp = &tr.lightallShader[index];

		backEnd.pc.c_lightallDraws++;

		GLSL_BindProgram(sp);

		GLSL_SetUniformMat4(sp, UNIFORM_MODELVIEWPROJECTIONMATRIX, glState.modelviewProjection);

		GLSL_SetUniformVec3(sp, UNIFORM_VIEWORIGIN, backEnd.viewParms.or.origin);

		GLSL_SetUniformVec3(sp, UNIFORM_LOCALVIEWORIGIN, backEnd.or.viewOrigin);

		GLSL_SetUniformFloat(sp, UNIFORM_VERTEXLERP, glState.vertexAttribsInterpolation);

		if(glState.boneAnimation) {
			GLSL_SetUniformMat4BoneMatrix(sp, UNIFORM_BONEMATRIX, glState.boneMatrix, glState.boneAnimation);
		}

		/*
		 * DEFORM
		 */
		GLSL_SetUniformInt(sp, UNIFORM_DEFORMGEN, deformGen);

		if(deformGen != DGEN_NONE) {
			GLSL_SetUniformFloat5(sp, UNIFORM_DEFORMPARAMS, deformParams);

			GLSL_SetUniformFloat(sp, UNIFORM_TIME, tess.shaderTime);
		}

		{
			vec4_t baseColor;
			vec4_t vertColor;

			ComputeShaderColors(pStage, baseColor, vertColor, GLS_SRCBLEND_ONE | GLS_DSTBLEND_ONE);

			GLSL_SetUniformVec4(sp, UNIFORM_BASECOLOR, baseColor);
			GLSL_SetUniformVec4(sp, UNIFORM_VERTCOLOR, vertColor);
		}

		GLSL_SetUniformInt(sp, UNIFORM_COLORGEN, pStage->rgbGen);

		GLSL_SetUniformInt(sp, UNIFORM_ALPHAGEN, pStage->alphaGen);

		/*
		 * DLIGHT
		 */
		VectorScale(dl->color, intensity, vector);

		GLSL_SetUniformVec3(sp, UNIFORM_DIRECTEDLIGHT, vector);

		VectorSet(vector, 0, 0, 0);

		GLSL_SetUniformVec3(sp, UNIFORM_AMBIENTLIGHT, vector);

		VectorCopy(dl->origin, vector);

		vector[3] = 1.0f;

		GLSL_SetUniformVec4(sp, UNIFORM_LIGHTORIGIN, vector);

		GLSL_SetUniformFloat(sp, UNIFORM_LIGHTRADIUS, radius);

		GLSL_SetUniformVec4(sp, UNIFORM_NORMALSCALE, pStage->normalScale);

		GLSL_SetUniformVec4(sp, UNIFORM_SPECULARSCALE, pStage->specularScale);

		/*
		 * ORIGINAL ADDITIVE DLIGHT
		 */
		GL_State(GLS_SRCBLEND_ONE | GLS_DSTBLEND_ONE | GLS_DEPTHFUNC_EQUAL);

		GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, 0);

		GLSL_SetUniformFloat(sp, UNIFORM_ALPHATESTREF, 0.0f);

		GLSL_SetUniformMat4(sp, UNIFORM_MODELMATRIX, backEnd.or.transformMatrix);

		/*
		 * IMPORTANT:
		 *
		 * Use stage 0 textures because stage 0 is the base material.
		 */
		if(pStage->bundle[TB_DIFFUSEMAP].image[0]) {
			R_BindAnimatedImageToTMU(&pStage->bundle[TB_DIFFUSEMAP], TB_DIFFUSEMAP);
		}

		if(pStage->bundle[TB_NORMALMAP].image[0]) {
			R_BindAnimatedImageToTMU(&pStage->bundle[TB_NORMALMAP], TB_NORMALMAP);
		} else if(r_normalMapping->integer) {
			GL_BindToTMU(tr.whiteImage, TB_NORMALMAP);
		}

		if(pStage->bundle[TB_SPECULARMAP].image[0]) {
			R_BindAnimatedImageToTMU(&pStage->bundle[TB_SPECULARMAP], TB_SPECULARMAP);
		} else if(r_specularMapping->integer) {
			GL_BindToTMU(tr.whiteImage, TB_SPECULARMAP);
		}

		{
			vec4_t enableTextures;
			VectorSet4(enableTextures, 0.0f, 0.0f, 0.0f, 0.0f);
			GLSL_SetUniformVec4(sp, UNIFORM_ENABLETEXTURES, enableTextures);
		}

		if(r_dlightMode->integer >= 2) GL_BindToTMU(tr.shadowCubemaps[l], TB_SHADOWMAP4);

		ComputeTexMods(pStage, TB_DIFFUSEMAP, texMatrix);

		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX0, texMatrix[0]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX1, texMatrix[1]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX2, texMatrix[2]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX3, texMatrix[3]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX4, texMatrix[4]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX5, texMatrix[5]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX6, texMatrix[6]);
		GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX7, texMatrix[7]);

		GLSL_SetUniformInt(sp, UNIFORM_TCGEN0, pStage->bundle[0].tcGen);

		/*
		 * DRAW
		 */
		R_DrawElements(input->numIndexes, input->firstIndex);

		backEnd.pc.c_totalIndexes += tess.numIndexes;
		backEnd.pc.c_dlightIndexes += tess.numIndexes;
		backEnd.pc.c_dlightVertexes += tess.numVertexes;
	}
}

/*
===================
RB_FogSetupShader

Общий setup для обоих под-проходов тумана:
биндит нужный fog-шейдер, ставит матрицу/deform/alpha-test/GL_State.
===================
*/
static shaderProgram_t* RB_FogSetupShader(int deformGen, vec5_t deformParams) {
	shaderProgram_t* sp;
	int index = 0;

	if(deformGen != DGEN_NONE) index |= FOGDEF_USE_DEFORM_VERTEXES;

	if(glState.vertexAnimation)
		index |= FOGDEF_USE_VERTEX_ANIMATION;
	else if(glState.boneAnimation)
		index |= FOGDEF_USE_BONE_ANIMATION;

	sp = &tr.fogShader[index];

	backEnd.pc.c_fogDraws++;

	GLSL_BindProgram(sp);

	GLSL_SetUniformMat4(sp, UNIFORM_MODELVIEWPROJECTIONMATRIX, glState.modelviewProjection);
	GLSL_SetUniformFloat(sp, UNIFORM_VERTEXLERP, glState.vertexAttribsInterpolation);

	if(glState.boneAnimation) {
		GLSL_SetUniformMat4BoneMatrix(sp, UNIFORM_BONEMATRIX, glState.boneMatrix, glState.boneAnimation);
	}

	GLSL_SetUniformInt(sp, UNIFORM_DEFORMGEN, deformGen);
	if(deformGen != DGEN_NONE) {
		GLSL_SetUniformFloat5(sp, UNIFORM_DEFORMPARAMS, deformParams);
		GLSL_SetUniformFloat(sp, UNIFORM_TIME, tess.shaderTime);
	}

	GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, 0);

	if(tess.shader->fogPass == FP_EQUAL) {
		GL_State(GLS_SRCBLEND_SRC_ALPHA | GLS_DSTBLEND_ONE_MINUS_SRC_ALPHA | GLS_DEPTHFUNC_EQUAL);
	} else {
		GL_State(GLS_SRCBLEND_SRC_ALPHA | GLS_DSTBLEND_ONE_MINUS_SRC_ALPHA);
	}

	return sp;
}

/*
===================
RB_FogPass

Теперь вызывается один раз на поверхность, но внутри делает
ДВА независимых прохода:
  1) туман из fog-браша (если tess.fogNum > 0)
  2) глобальный dynamicFog (если r_dynamicFog)
Порядок именно такой: сначала плотный локальный туман,
поверх него — атмосферный. Смешение идёт обычным alpha-blend'ом
(SRC_ALPHA, ONE_MINUS_SRC_ALPHA), поэтому второй проход
естественным образом ложится на первый:
    out = dyn*a_d + (brush*a_b + old*(1-a_b)) * (1-a_d)
===================
*/
void RB_FogPass(void) {
	int deformGen;
	vec5_t deformParams;
	bool hasWorldFog;
	bool hasDynamicFog;

	if(!tess.numIndexes || !tr.world) {
		return;
	}

	hasWorldFog = (tess.fogNum > 0 && tess.fogNum < tr.world->numfogs);
	hasDynamicFog = (r_dynamicFog->integer != 0);

	if(!hasWorldFog && !hasDynamicFog) {
		return;
	}

	ComputeDeformValues(&deformGen, deformParams);

	/* ---------- 1) туман из fog-браша (объёмный) ---------- */
	if(hasWorldFog) {
		shaderProgram_t* sp;
		fog_t* fog;
		vec4_t color;
		vec4_t fogDistanceVector, fogDepthVector = {0, 0, 0, 0};
		float eyeT = 0;

		fog = tr.world->fogs + tess.fogNum;

		color[0] = ((unsigned char*)(&fog->colorInt))[0] / 255.0f;
		color[1] = ((unsigned char*)(&fog->colorInt))[1] / 255.0f;
		color[2] = ((unsigned char*)(&fog->colorInt))[2] / 255.0f;
		color[3] = ((unsigned char*)(&fog->colorInt))[3] / 255.0f;

		sp = RB_FogSetupShader(deformGen, deformParams);

		GLSL_SetUniformVec4(sp, UNIFORM_COLOR, color);

		ComputeFogValues(fogDistanceVector, fogDepthVector, &eyeT);

		GLSL_SetUniformVec4(sp, UNIFORM_FOGDISTANCE, fogDistanceVector);
		GLSL_SetUniformVec4(sp, UNIFORM_FOGDEPTH, fogDepthVector);
		GLSL_SetUniformFloat(sp, UNIFORM_FOGEYET, eyeT);

		R_DrawElements(tess.numIndexes, tess.firstIndex);
	}

	/* ---------- 2) динамический туман поверх объёмного ---------- */
	if(hasDynamicFog) {
		shaderProgram_t* sp;
		vec4_t color;
		vec4_t fogDistanceVector, fogDepthVector = {0, 0, 0, 0};
		float eyeT;
		float startDist = r_dynamicFogStart->value;
		float endDist = r_dynamicFogEnd->value;
		float range = endDist - startDist;
		float scale;
		vec3_t local;

		if(range < 1.0f) range = 1.0f;

		// vertex-шейдер умножает dot-произведение на 8.0,
		// поэтому для линейной рампы 0..1 на участке range нужен /8.
		scale = r_dynamicFogDensity->value / (8.0f * range);

		color[0] = r_dynamicFogColorR->value;
		color[1] = r_dynamicFogColorG->value;
		color[2] = r_dynamicFogColorB->value;
		color[3] = 1.0f;

		sp = RB_FogSetupShader(deformGen, deformParams);

		GLSL_SetUniformVec4(sp, UNIFORM_COLOR, color);

		VectorSubtract(backEnd.or.origin, backEnd.viewParms.or.origin, local);

		fogDistanceVector[0] = -backEnd.or.modelMatrix[2] * scale;
		fogDistanceVector[1] = -backEnd.or.modelMatrix[6] * scale;
		fogDistanceVector[2] = -backEnd.or.modelMatrix[10] * scale;
		fogDistanceVector[3] = (DotProduct(local, backEnd.viewParms.or.axis[0]) - startDist) * scale;

		// у динамического тумана нет плоскости отсечения,
		// поэтому t в CalcFog() всегда = 1
		fogDepthVector[0] = 0.0f;
		fogDepthVector[1] = 0.0f;
		fogDepthVector[2] = 0.0f;
		fogDepthVector[3] = 1.0f;

		eyeT = 1.0f;

		GLSL_SetUniformVec4(sp, UNIFORM_FOGDISTANCE, fogDistanceVector);
		GLSL_SetUniformVec4(sp, UNIFORM_FOGDEPTH, fogDepthVector);
		GLSL_SetUniformFloat(sp, UNIFORM_FOGEYET, eyeT);

		R_DrawElements(tess.numIndexes, tess.firstIndex);
	}
}

static unsigned int RB_CalcShaderVertexAttribs(shaderCommands_t* input) {
	unsigned int vertexAttribs = input->shader->vertexAttribs;

	if(glState.vertexAnimation) {
		vertexAttribs |= ATTR_POSITION2;
		if(vertexAttribs & ATTR_NORMAL) {
			vertexAttribs |= ATTR_NORMAL2;
			vertexAttribs |= ATTR_TANGENT2;
		}
	}

	return vertexAttribs;
}

static void RB_IterateStagesGeneric(shaderCommands_t* input) {
	int stage;
	bool overridealpha = false;
	int oldAlphaGen = AGEN_IDENTITY;
	int oldStateBits = 0;
	bool overridecolor = false;
	int oldRgbGen = CGEN_IDENTITY;

	vec4_t fogDistanceVector, fogDepthVector = {0, 0, 0, 0};
	float eyeT = 0;

	int deformGen;
	vec5_t deformParams;

	bool renderToCubemap = tr.renderCubeFbo && glState.currentFBO == tr.renderCubeFbo;

	ComputeDeformValues(&deformGen, deformParams);

	ComputeFogValues(fogDistanceVector, fogDepthVector, &eyeT);

	for(stage = 0; stage < MAX_SHADER_STAGES; stage++) {
		shaderStage_t* pStage = input->xstages[stage];
		shaderProgram_t* sp;
		vec4_t texMatrix[8];

		if(!pStage) {
			break;
		}

		// override the shader alpha channel if requested
		if(backEnd.currentEntity && backEnd.currentEntity->e.renderfx & RF_FORCE_ENT_ALPHA) {
			overridealpha = true;
			oldAlphaGen = pStage->alphaGen;
			oldStateBits = pStage->stateBits;
			pStage->alphaGen = AGEN_ENTITY;

			// set bits for blendfunc blend
			pStage->stateBits = GLS_SRCBLEND_SRC_ALPHA | GLS_DSTBLEND_ONE_MINUS_SRC_ALPHA;

			// keep the original alphafunc, if any
			pStage->stateBits |= (oldStateBits & GLS_ATEST_BITS);
		} else {
			overridealpha = false;
		}

		// override the shader color channels if requested
		if(backEnd.currentEntity && backEnd.currentEntity->e.renderfx & RF_RGB_TINT) {
			overridecolor = true;
			oldRgbGen = pStage->rgbGen;
			pStage->rgbGen = CGEN_ENTITY;
		} else {
			overridecolor = false;
		}

		if(backEnd.depthFill) {
			if(pStage->glslShaderGroup == tr.lightallShader) {
				int index = 0;

				if(backEnd.currentEntity && backEnd.currentEntity != &tr.worldEntity) {
					if(glState.boneAnimation) {
						index |= LIGHTDEF_ENTITY_BONE_ANIMATION;
					} else {
						index |= LIGHTDEF_ENTITY_VERTEX_ANIMATION;
					}
				}

				if(pStage->stateBits & GLS_ATEST_BITS) {
					index |= LIGHTDEF_USE_TCGEN_AND_TCMOD;
				}

				sp = &pStage->glslShaderGroup[index];
			} else {
				int shaderAttribs = 0;

				if(tess.shader->numDeforms && !ShaderRequiresCPUDeforms(tess.shader)) {
					shaderAttribs |= GENERICDEF_USE_DEFORM_VERTEXES;
				}

				if(glState.vertexAnimation) {
					shaderAttribs |= GENERICDEF_USE_VERTEX_ANIMATION;
				} else if(glState.boneAnimation) {
					shaderAttribs |= GENERICDEF_USE_BONE_ANIMATION;
				}

				if(pStage->stateBits & GLS_ATEST_BITS) {
					shaderAttribs |= GENERICDEF_USE_TCGEN_AND_TCMOD;
				}

				sp = &tr.genericShader[shaderAttribs];
			}
		} else if(pStage->glslShaderGroup == tr.lightallShader) {
			int index = pStage->glslShaderIndex;

			if(backEnd.currentEntity && backEnd.currentEntity != &tr.worldEntity) {
				if(glState.boneAnimation) {
					index |= LIGHTDEF_ENTITY_BONE_ANIMATION;
				} else {
					index |= LIGHTDEF_ENTITY_VERTEX_ANIMATION;
				}
			}

			if(r_sunShadows->integer && (backEnd.viewParms.flags & VPF_USESUNLIGHT) && (index & LIGHTDEF_LIGHTTYPE_MASK)) {
				index |= LIGHTDEF_USE_SHADOWMAP;
			}

			if(r_lightmap->integer && ((index & LIGHTDEF_LIGHTTYPE_MASK) == LIGHTDEF_USE_LIGHTMAP)) {
				index = LIGHTDEF_USE_TCGEN_AND_TCMOD;
			}

			sp = &pStage->glslShaderGroup[index];

			backEnd.pc.c_lightallDraws++;
		} else {
			sp = GLSL_GetGenericShaderProgram(stage);

			backEnd.pc.c_genericDraws++;
		}

		GLSL_BindProgram(sp);

		GLSL_SetUniformMat4(sp, UNIFORM_MODELVIEWPROJECTIONMATRIX, glState.modelviewProjection);
		GLSL_SetUniformVec3(sp, UNIFORM_VIEWORIGIN, backEnd.viewParms.or.origin);
		GLSL_SetUniformVec3(sp, UNIFORM_LOCALVIEWORIGIN, backEnd.or.viewOrigin);

		GLSL_SetUniformFloat(sp, UNIFORM_VERTEXLERP, glState.vertexAttribsInterpolation);

		if(glState.boneAnimation) {
			GLSL_SetUniformMat4BoneMatrix(sp, UNIFORM_BONEMATRIX, glState.boneMatrix, glState.boneAnimation);
		}

		GLSL_SetUniformInt(sp, UNIFORM_DEFORMGEN, deformGen);
		if(deformGen != DGEN_NONE) {
			GLSL_SetUniformFloat5(sp, UNIFORM_DEFORMPARAMS, deformParams);
			GLSL_SetUniformFloat(sp, UNIFORM_TIME, tess.shaderTime);
		}

		GL_State(pStage->stateBits);

		// alpha test function
		switch(pStage->stateBits & GLS_ATEST_FUNC_BITS) {
			case GLS_ATEST_GREATER: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_GREATER); break;
			case GLS_ATEST_LESS: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_LESS); break;
			case GLS_ATEST_GREATEREQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_GREATEREQUAL); break;
			case GLS_ATEST_LESSEQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_LESSEQUAL); break;
			case GLS_ATEST_EQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_EQUAL); break;
			case GLS_ATEST_NOTEQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_NOTEQUAL); break;
			default: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_NONE); break;
		}

		// alpha test reference value
		GLSL_SetUniformFloat(sp, UNIFORM_ALPHATESTREF, ((pStage->stateBits & GLS_ATEST_REF_BITS) >> GLS_ATEST_REF_SHIFT) / 100.0f);

		{
			vec4_t baseColor;
			vec4_t vertColor;

			ComputeShaderColors(pStage, baseColor, vertColor, pStage->stateBits);

			GLSL_SetUniformVec4(sp, UNIFORM_BASECOLOR, baseColor);
			GLSL_SetUniformVec4(sp, UNIFORM_VERTCOLOR, vertColor);
		}

		if(pStage->rgbGen == CGEN_LIGHTING_DIFFUSE || pStage->rgbGen == CGEN_LIGHTING_DIFFUSE_ENTITY) {
			vec3_t ambient, directed;
			vec4_t vec;
			trRefEntity_t* ent = backEnd.currentEntity;

			VectorCopy(ent->ambientLight, ambient);
			VectorCopy(ent->directedLight, directed);

			VectorScale(ambient, 1.0f / 255.0f, vec);
			GLSL_SetUniformVec3(sp, UNIFORM_AMBIENTLIGHT, vec);

			VectorScale(directed, 1.0f / 255.0f, vec);
			GLSL_SetUniformVec3(sp, UNIFORM_DIRECTEDLIGHT, vec);

			VectorCopy(ent->lightDir, vec);
			vec[3] = 0.0f;
			GLSL_SetUniformVec4(sp, UNIFORM_LIGHTORIGIN, vec);
			GLSL_SetUniformVec3(sp, UNIFORM_MODELLIGHTDIR, ent->modelLightDir);

			GLSL_SetUniformFloat(sp, UNIFORM_LIGHTRADIUS, 0.0f);

			if(pStage->rgbGen == CGEN_LIGHTING_DIFFUSE_ENTITY) {
				int i;
				for(i = 0; i < 3; i++) vec[i] = ent->e.shaderRGBA[i] / 255.0f;
				GLSL_SetUniformVec3(sp, UNIFORM_DIFFUSECOLOR, vec);
			}
		}

		if(pStage->alphaGen == AGEN_PORTAL) {
			GLSL_SetUniformFloat(sp, UNIFORM_PORTALRANGE, tess.shader->portalRange);
		}

		GLSL_SetUniformInt(sp, UNIFORM_COLORGEN, pStage->rgbGen);
		GLSL_SetUniformInt(sp, UNIFORM_ALPHAGEN, pStage->alphaGen);

		if(r_lightmap->integer) {
			vec4_t st[2];
			VectorSet4(st[0], 1.0f, 0.0f, 0.0f, 0.0f);
			VectorSet4(st[1], 0.0f, 1.0f, 0.0f, 0.0f);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX0, st[0]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX1, st[1]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX2, st[0]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX3, st[1]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX4, st[0]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX5, st[1]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX6, st[0]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX7, st[1]);

			GLSL_SetUniformInt(sp, UNIFORM_TCGEN0, TCGEN_LIGHTMAP);
		} else {
			ComputeTexMods(pStage, TB_DIFFUSEMAP, texMatrix);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX0, texMatrix[0]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX1, texMatrix[1]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX2, texMatrix[2]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX3, texMatrix[3]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX4, texMatrix[4]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX5, texMatrix[5]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX6, texMatrix[6]);
			GLSL_SetUniformVec4(sp, UNIFORM_DIFFUSETEXMATRIX7, texMatrix[7]);

			GLSL_SetUniformInt(sp, UNIFORM_TCGEN0, pStage->bundle[0].tcGen);
			if(pStage->bundle[0].tcGen == TCGEN_VECTOR) {
				vec3_t vec;

				VectorCopy(pStage->bundle[0].tcGenVectors[0], vec);
				GLSL_SetUniformVec3(sp, UNIFORM_TCGEN0VECTOR0, vec);
				VectorCopy(pStage->bundle[0].tcGenVectors[1], vec);
				GLSL_SetUniformVec3(sp, UNIFORM_TCGEN0VECTOR1, vec);
			}
		}

		GLSL_SetUniformMat4(sp, UNIFORM_MODELMATRIX, backEnd.or.transformMatrix);

		GLSL_SetUniformVec4(sp, UNIFORM_NORMALSCALE, pStage->normalScale);

		{
			vec4_t specularScale;
			Vector4Copy(pStage->specularScale, specularScale);

			if(renderToCubemap) {
				// force specular to nonmetal if rendering cubemaps
				if(r_pbr->integer) specularScale[1] = 0.0f;
			}

			GLSL_SetUniformVec4(sp, UNIFORM_SPECULARSCALE, specularScale);
		}

		// GLSL_SetUniformFloat(sp, UNIFORM_MAPLIGHTSCALE, backEnd.refdef.mapLightScale);

		//
		// do multitexture
		//
		if(backEnd.depthFill) {
			if(!(pStage->stateBits & GLS_ATEST_BITS))
				GL_BindToTMU(tr.whiteImage, TB_COLORMAP);
			else if(pStage->bundle[TB_COLORMAP].image[0] != 0)
				R_BindAnimatedImageToTMU(&pStage->bundle[TB_COLORMAP], TB_COLORMAP);
		} else if(pStage->glslShaderGroup == tr.lightallShader) {
			int i;
			vec4_t enableTextures;

			if(r_sunShadows->integer && (backEnd.viewParms.flags & VPF_USESUNLIGHT) && (pStage->glslShaderIndex & LIGHTDEF_LIGHTTYPE_MASK)) {
				// FIXME: screenShadowImage is NULL if no framebuffers
				if(tr.screenShadowImage) GL_BindToTMU(tr.screenShadowImage, TB_SHADOWMAP);
				GLSL_SetUniformVec3(sp, UNIFORM_PRIMARYLIGHTAMBIENT, backEnd.refdef.sunAmbCol);
				if(r_pbr->integer) {
					vec3_t color;

					color[0] = backEnd.refdef.sunCol[0] * backEnd.refdef.sunCol[0];
					color[1] = backEnd.refdef.sunCol[1] * backEnd.refdef.sunCol[1];
					color[2] = backEnd.refdef.sunCol[2] * backEnd.refdef.sunCol[2];
					GLSL_SetUniformVec3(sp, UNIFORM_PRIMARYLIGHTCOLOR, color);
				} else {
					GLSL_SetUniformVec3(sp, UNIFORM_PRIMARYLIGHTCOLOR, backEnd.refdef.sunCol);
				}
				GLSL_SetUniformVec4(sp, UNIFORM_PRIMARYLIGHTORIGIN, backEnd.refdef.sunDir);
			}

			VectorSet4(enableTextures, 0, 0, 0, 0);
			if((r_lightmap->integer == 1 || r_lightmap->integer == 2) && pStage->bundle[TB_LIGHTMAP].image[0]) {
				for(i = 0; i < NUM_TEXTURE_BUNDLES; i++) {
					if(i == TB_COLORMAP)
						R_BindAnimatedImageToTMU(&pStage->bundle[TB_LIGHTMAP], i);
					else
						GL_BindToTMU(tr.whiteImage, i);
				}
			} else if(r_lightmap->integer == 3 && pStage->bundle[TB_DELUXEMAP].image[0]) {
				for(i = 0; i < NUM_TEXTURE_BUNDLES; i++) {
					if(i == TB_COLORMAP)
						R_BindAnimatedImageToTMU(&pStage->bundle[TB_DELUXEMAP], i);
					else
						GL_BindToTMU(tr.whiteImage, i);
				}
			} else {
				bool light = (pStage->glslShaderIndex & LIGHTDEF_LIGHTTYPE_MASK) != 0;
				bool fastLight = !(r_normalMapping->integer || r_specularMapping->integer);

				if(pStage->bundle[TB_DIFFUSEMAP].image[0]) R_BindAnimatedImageToTMU(&pStage->bundle[TB_DIFFUSEMAP], TB_DIFFUSEMAP);

				if(pStage->bundle[TB_LIGHTMAP].image[0]) R_BindAnimatedImageToTMU(&pStage->bundle[TB_LIGHTMAP], TB_LIGHTMAP);

				// bind textures that are sampled and used in the glsl shader, and
				// bind whiteImage to textures that are sampled but zeroed in the glsl shader
				//
				// alternatives:
				//  - use the last bound texture
				//     -> costs more to sample a higher res texture then throw out the result
				//  - disable texture sampling in glsl shader with #ifdefs, as before
				//     -> increases the number of shaders that must be compiled
				//
				if(light && !fastLight) {
					if(pStage->bundle[TB_NORMALMAP].image[0]) {
						R_BindAnimatedImageToTMU(&pStage->bundle[TB_NORMALMAP], TB_NORMALMAP);
						enableTextures[0] = 1.0f;
					} else if(r_normalMapping->integer)
						GL_BindToTMU(tr.whiteImage, TB_NORMALMAP);

					if(pStage->bundle[TB_DELUXEMAP].image[0]) {
						R_BindAnimatedImageToTMU(&pStage->bundle[TB_DELUXEMAP], TB_DELUXEMAP);
						enableTextures[1] = 1.0f;
					} else if(r_deluxeMapping->integer)
						GL_BindToTMU(tr.whiteImage, TB_DELUXEMAP);

					if(pStage->bundle[TB_SPECULARMAP].image[0]) {
						R_BindAnimatedImageToTMU(&pStage->bundle[TB_SPECULARMAP], TB_SPECULARMAP);
						enableTextures[2] = 1.0f;
					} else if(r_specularMapping->integer)
						GL_BindToTMU(tr.whiteImage, TB_SPECULARMAP);
				}

				enableTextures[3] = (r_reflections->integer && !(tr.viewParms.flags & VPF_NOCUBEMAPS) && input->useCubemap) ? 1.0f : 0.0f;
			}

			GLSL_SetUniformVec4(sp, UNIFORM_ENABLETEXTURES, enableTextures);
		} else if(pStage->bundle[1].image[0] != 0) {
			R_BindAnimatedImageToTMU(&pStage->bundle[0], 0);

			//
			// lightmap/secondary pass
			//
			if(r_lightmap->integer && pStage->bundle[1].isLightmap) {
				GLSL_SetUniformInt(sp, UNIFORM_TEXTURE1ENV, GL_REPLACE);
			} else {
				GLSL_SetUniformInt(sp, UNIFORM_TEXTURE1ENV, pStage->multitextureEnv);
			}

			R_BindAnimatedImageToTMU(&pStage->bundle[1], 1);
		} else {
			//
			// set state
			//
			R_BindAnimatedImageToTMU(&pStage->bundle[0], 0);

			GLSL_SetUniformInt(sp, UNIFORM_TEXTURE1ENV, 0);
		}

		// testing cube map
		if(!(tr.viewParms.flags & VPF_NOCUBEMAPS) && input->useCubemap && r_reflections->integer) {
			vec3_t vec3;
			vec4_t vec4;

			cubemap_t* cubemap = tr.cubemap;

			if(cubemap->image) GL_BindToTMU(cubemap->image, TB_CUBEMAP);

			float dx = backEnd.viewParms.or.origin[0] - input->cubemapOrigin[0];
			float dy = backEnd.viewParms.or.origin[1] - input->cubemapOrigin[1];
			float dz = backEnd.viewParms.or.origin[2] - input->cubemapOrigin[2];
			float distXYZ = sqrtf(dx * dx + dy * dy + dz * dz);

			if(input->cubemapBound != 0.0f) {
				vec4[0] = backEnd.viewParms.or.origin[2];  // Z камеры
				vec4[1] = input->cubemapOrigin[2];         // Z поверхности
				vec4[2] = distXYZ;                         // Полное 3D-расстояние (distXYZ)
			} else {
				vec4[0] = 0.0f;  // Z камеры
				vec4[1] = 0.0f;  // Z поверхности
				vec4[2] = 1.0f;  // Полное 3D-расстояние (distXYZ)
			}
			vec4[3] = input->cubemapBound;  // Сторона
			GLSL_SetUniformVec4(sp, UNIFORM_CUBEMAPINFO, vec4);

			VectorSubtract(cubemap->origin, backEnd.viewParms.or.origin, vec3);
			VectorScale(vec3, 1.0f / 65536, vec3);
			GLSL_SetUniformVec3(sp, UNIFORM_CUBEMAPARALLAXINFO, vec3);
		}

		//
		// draw
		//
		R_DrawElements(input->numIndexes, input->firstIndex);

		if(tess.dlightBits && tess.shader->sort <= SS_OPAQUE && !(tess.shader->surfaceFlags & SURF_SKY)) {
			ForwardDlightEnt(pStage);
		}

		if(overridealpha) {
			pStage->alphaGen = oldAlphaGen;
			pStage->stateBits = oldStateBits;
		}

		if(overridecolor) {
			pStage->rgbGen = oldRgbGen;
		}

		// allow skipping out to show just lightmaps during development
		if(r_lightmap->integer && (pStage->bundle[0].isLightmap || pStage->bundle[1].isLightmap)) {
			break;
		}

		if(backEnd.depthFill) break;
	}
}

static void RB_RenderShadowmap(shaderCommands_t* input) {
	int deformGen;
	vec5_t deformParams;

	ComputeDeformValues(&deformGen, deformParams);

	{
		shaderProgram_t* sp = &tr.shadowmapShader[0];

		if(glState.vertexAnimation) {
			sp = &tr.shadowmapShader[SHADOWMAPDEF_USE_VERTEX_ANIMATION];
		} else if(glState.boneAnimation) {
			sp = &tr.shadowmapShader[SHADOWMAPDEF_USE_BONE_ANIMATION];
		}

		vec4_t vector;

		GLSL_BindProgram(sp);

		GLSL_SetUniformMat4(sp, UNIFORM_MODELVIEWPROJECTIONMATRIX, glState.modelviewProjection);

		mat4_t modelMatrix;

		if(backEnd.currentEntity == &tr.worldEntity) {
			Mat4Identity(modelMatrix);
		} else {
			Mat4Copy(backEnd.or.transformMatrix, modelMatrix);
		}

		GLSL_SetUniformMat4(sp, UNIFORM_MODELMATRIX, modelMatrix);

		GLSL_SetUniformFloat(sp, UNIFORM_VERTEXLERP, glState.vertexAttribsInterpolation);

		if(glState.boneAnimation) {
			GLSL_SetUniformMat4BoneMatrix(sp, UNIFORM_BONEMATRIX, glState.boneMatrix, glState.boneAnimation);
		}

		GLSL_SetUniformInt(sp, UNIFORM_DEFORMGEN, deformGen);
		if(deformGen != DGEN_NONE) {
			GLSL_SetUniformFloat5(sp, UNIFORM_DEFORMPARAMS, deformParams);
			GLSL_SetUniformFloat(sp, UNIFORM_TIME, tess.shaderTime);

			if(tess.shader->deforms[0].deformationWave.frequency < 0) {
				vec3_t worldUp;
				vec3_t fireRiseDir = {0, 0, 1};

				if(!VectorCompare(backEnd.currentEntity->e.fireRiseDir, vec3_origin)) {
					VectorCopy(backEnd.currentEntity->e.fireRiseDir, fireRiseDir);
				}

				if(backEnd.currentEntity != &tr.worldEntity) {  // world surfaces dont have an axis
					VectorRotate(fireRiseDir, backEnd.currentEntity->e.axis, worldUp);
				} else {
					VectorCopy(fireRiseDir, worldUp);
				}

				GLSL_SetUniformVec3(sp, UNIFORM_FIRERISEDIR, worldUp);
			}
		}

		VectorCopy(backEnd.viewParms.or.origin, vector);
		vector[3] = 1.0f;
		GLSL_SetUniformVec4(sp, UNIFORM_LIGHTORIGIN, vector);
		GLSL_SetUniformFloat(sp, UNIFORM_LIGHTRADIUS, backEnd.viewParms.zFar);

		GL_State(GLS_DEFAULT);

		{
			shaderStage_t* pStage = input->xstages[0];

			if(pStage) {
				/*
				 * Bind the actual diffuse texture so the shadow shader
				 * can test its alpha channel.
				 */
				if(pStage->bundle[TB_DIFFUSEMAP].image[0]) {
					R_BindAnimatedImageToTMU(&pStage->bundle[TB_DIFFUSEMAP], TB_DIFFUSEMAP);
				}

				/*
				 * Use the same alpha-test mode as the material.
				 */
				switch(pStage->stateBits & GLS_ATEST_FUNC_BITS) {
					case GLS_ATEST_GREATER: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_GREATER); break;

					case GLS_ATEST_LESS: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_LESS); break;

					case GLS_ATEST_GREATEREQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_GREATEREQUAL); break;

					case GLS_ATEST_LESSEQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_LESSEQUAL); break;

					case GLS_ATEST_EQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_EQUAL); break;

					case GLS_ATEST_NOTEQUAL: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_NOTEQUAL); break;

					default: GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_NONE); break;
				}

				GLSL_SetUniformFloat(sp, UNIFORM_ALPHATESTREF, ((pStage->stateBits & GLS_ATEST_REF_BITS) >> GLS_ATEST_REF_SHIFT) / 100.0f);
			} else {
				GLSL_SetUniformInt(sp, UNIFORM_ALPHATEST, U_ATEST_NONE);

				GLSL_SetUniformFloat(sp, UNIFORM_ALPHATESTREF, 0.0f);
			}
		}

		R_DrawElements(input->numIndexes, input->firstIndex);
	}
}

void RB_StageIteratorGeneric(void) {
	shaderCommands_t* input;
	unsigned int vertexAttribs = 0;

	input = &tess;

	if(!input->numVertexes || !input->numIndexes) {
		return;
	}

	if(tess.useInternalVao) {
		RB_DeformTessGeometry();
	}

	vertexAttribs = RB_CalcShaderVertexAttribs(input);

	if(tess.useInternalVao) {
		RB_UpdateTessVao(vertexAttribs);
	} else {
		backEnd.pc.c_staticVaoDraws++;
	}

	//
	// log this call
	//
	if(r_logFile->integer) {
		// don't just call LogComment, or we will get
		// a call to va() every frame!
		GLimp_LogComment(va("--- RB_StageIteratorGeneric( %s ) ---\n", tess.shader->name));
	}

	//
	// set face culling appropriately
	//
	if(input->shader->cullType == CT_TWO_SIDED) {
		GL_Cull(CT_TWO_SIDED);
	} else {
		bool cullFront = (input->shader->cullType == CT_FRONT_SIDED);

		if(backEnd.viewParms.flags & VPF_DEPTHSHADOW) cullFront = !cullFront;

		if(backEnd.viewParms.isMirror) cullFront = !cullFront;

		if(backEnd.currentEntity && backEnd.currentEntity->mirrored) cullFront = !cullFront;

		if(cullFront)
			GL_Cull(CT_FRONT_SIDED);
		else
			GL_Cull(CT_BACK_SIDED);
	}

	// set polygon offset if necessary
	if(input->shader->polygonOffset) {
		qglEnable(GL_POLYGON_OFFSET_FILL);
		qglPolygonOffset(r_offsetFactor->value, r_offsetUnits->value);
	}

	//
	// render depth if in depthfill mode
	//
	if(backEnd.depthFill) {
		RB_IterateStagesGeneric(input);

		//
		// reset polygon offset
		//
		if(input->shader->polygonOffset) {
			qglDisable(GL_POLYGON_OFFSET_FILL);
		}

		return;
	}

	//
	// render shadowmap if in shadowmap mode
	//
	if(backEnd.viewParms.flags & VPF_SHADOWMAP) {
		if(input->shader->sort == SS_OPAQUE) {
			RB_RenderShadowmap(input);
		}
		//
		// reset polygon offset
		//
		if(input->shader->polygonOffset) {
			qglDisable(GL_POLYGON_OFFSET_FILL);
		}

		return;
	}

	//
	//
	// call shader function
	//
	RB_IterateStagesGeneric(input);

	// now do fog
	// не применяем туман для 2D-элементов интерфейса (projection2D),
	// иначе новый FP_LE для blend-шейдеров затронет HUD/меню
	if(tess.shader->fogPass && !backEnd.projection2D) {
		bool needsFogPass = false;

		if(tess.fogNum) {
			// Внутри BSP-объёма тумана — применяем всегда.
			needsFogPass = true;
		} else if(r_dynamicFog->integer && tr.world != NULL) {
			// Динамический туман — применяем только к поверхностям,
			// которые находятся дальше, чем r_dynamicFogStart.
			// Это избавляет от дорогого fog-pass для геометрии
			// прямо перед игроком.
			vec3_t worldPos;
			float dist;

			if(backEnd.currentEntity && backEnd.currentEntity != &tr.worldEntity) {
				// Для энтити используем origin как дешёвое приближение.
				VectorCopy(backEnd.currentEntity->e.origin, worldPos);
			} else {
				// Мировые поверхности: tess.xyz уже в мировых координатах.
				VectorCopy(tess.xyz[0], worldPos);
			}

			VectorSubtract(worldPos, backEnd.viewParms.or.origin, worldPos);
			dist = VectorLength(worldPos);

			if(dist > r_dynamicFogStart->value) {
				needsFogPass = true;
			}
		}

		if(needsFogPass) {
			RB_FogPass();
		}
	}

	//
	// reset polygon offset
	//
	if(input->shader->polygonOffset) {
		qglDisable(GL_POLYGON_OFFSET_FILL);
	}
}

/*
** RB_EndSurface
*/
void RB_EndSurface(void) {
	shaderCommands_t* input;

	input = &tess;

	if(input->numIndexes == 0 || input->numVertexes == 0) {
		return;
	}

	if(input->indexes[SHADER_MAX_INDEXES - 1] != 0) {
		ri.Error(ERR_DROP, "RB_EndSurface() - SHADER_MAX_INDEXES hit");
	}
	if(input->xyz[SHADER_MAX_VERTEXES - 1][0] != 0) {
		ri.Error(ERR_DROP, "RB_EndSurface() - SHADER_MAX_VERTEXES hit");
	}

	// for debugging of sort order issues, stop rendering after a given sort value
	if(r_debugSort->integer && r_debugSort->integer < tess.shader->sort) {
		return;
	}

	if(tess.useCacheVao) {
		// upload indexes now
		VaoCache_Commit();
	}

	//
	// update performance counters
	//
	backEnd.pc.c_shaders++;
	backEnd.pc.c_vertexes += tess.numVertexes;
	backEnd.pc.c_indexes += tess.numIndexes;
	backEnd.pc.c_totalIndexes += tess.numIndexes * tess.numPasses;

	//
	// call off to shader specific tess end function
	//
	tess.currentStageIteratorFunc();

	//
	// draw debugging stuff
	//
	if(r_showtris->integer) {
		DrawTris(input);
	}
	// clear shader so we can tell we don't have any unclosed surfaces
	tess.numIndexes = 0;
	tess.numVertexes = 0;
	tess.firstIndex = 0;
	tess.useCacheVao = false;
	tess.useInternalVao = false;

	GLimp_LogComment("----------\n");
}
