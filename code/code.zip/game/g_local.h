/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
//
// g_local.h -- local definitions for game module

#include "../qcommon/q_shared.h"
#include "../qcommon/vm_sharedsyscalls.h"
#include "bg_public.h"
#include "g_public.h"

// the "gameversion" client command will print this plus compile date
#define GAMEVERSION BASEGAME

#define BODY_QUEUE_SIZE 8

#define INFINITE 1000000

#define FRAMETIME 100  // msec
#define CARNAGE_REWARD_TIME 3000
#define REWARD_SPRITE_TIME 2000

#define INTERMISSION_DELAY_TIME 1000
#define SP_INTERMISSION_DELAY_TIME 5000

// gentity->flags
#define FL_GODMODE 0x00000010
#define FL_NOTARGET 0x00000020
#define FL_TEAMMEMBER 0x00000400  // not the first on the team
#define FL_NO_KNOCKBACK 0x00000800
#define FL_DROPPED_ITEM 0x00001000
#define FL_NO_BOTS 0x00002000    // spawn point not for bot use
#define FL_NO_HUMANS 0x00004000  // spawn point just for bots

// movers are things like doors, plats, buttons, etc
typedef enum { MOVER_POS1, MOVER_POS2, MOVER_1TO2, MOVER_2TO1 } moverState_t;

typedef struct gentity_s gentity_t;
typedef struct gclient_s gclient_t;

struct gentity_s {
	entityState_t s;   // communicated by server to clients
	entityShared_t r;  // shared by both the server system and game

	struct gclient_s* client;  // NULL if not a client

	bool inuse;

	char* classname;  // set in QuakeEd
	int spawnflags;   // set in QuakeEd

	bool neverFree;  // if true, FreeEntity will only unlink bodyque uses this

	int flags;  // FL_* variables

	char* model;
	char* model2;
	int freetime;  // level.time when the object was freed

	int eventTime;  // events will be cleared EVENT_VALID_MSEC after set
	bool freeAfterEvent;
	bool unlinkAfterEvent;

	bool physicsObject;   // if true, it can be pushed by movers and fall off edges
	float physicsBounce;  // 1.0 = continuous bounce, 0.0 = no bounce
	int clipmask;         // brushes with this content value will be collided against when moving.

	moverState_t moverState;
	int soundPos1;
	int sound1to2;
	int sound2to1;
	int soundPos2;
	int soundLoop;
	gentity_t* parent;
	gentity_t* nextTrain;
	gentity_t* prevTrain;
	vec3_t pos1, pos2;

	int timestamp;

	char* target;
	char* targetname;
	char* team;

	float speed;
	vec3_t movedir;

	int nextthink;
	void (*think)(gentity_t* self);
	void (*reached)(gentity_t* self);  // movers call this when hitting endpoint
	void (*blocked)(gentity_t* self, gentity_t* other);
	void (*touch)(gentity_t* self, gentity_t* other, trace_t* trace);
	void (*use)(gentity_t* self, gentity_t* other, gentity_t* activator);
	void (*pain)(gentity_t* self, gentity_t* attacker, int damage);
	void (*die)(gentity_t* self, gentity_t* inflictor, gentity_t* attacker, int damage, int mod);

	int pain_debounce_time;
	int fly_sound_debounce_time;

	int health;

	bool takedamage;

	int damage;
	int splashDamage;
	int splashRadius;

	int count;

	gentity_t* chain;
	gentity_t* enemy;
	gentity_t* activator;
	gentity_t* teamchain;
	gentity_t* teammaster;

	int watertype;
	int waterlevel;

	float wait;
	float random;

	item_t* item;

	int swep_list[MAX_WEAPONS];
	int swep_ammo[MAX_WEAPONS];

	// flashlight
	bool flashlight;

	// object private system
	gentity_t* owner;

	// Physgun and Gravitygun
	gentity_t* grabbedEntity;   // physgun object for player
	bool isGrabbed;             // object is grabbed by player for prop
	float grabDist;             // physgun distance for player
	vec3_t grabOffset;          // physgun offset for player
	vec3_t grabOrigin;          // local grab point on the prop (where crosshair hit)
	vec3_t grabOldOrigin;       // physgun old origin for prop
	float grabLastPlayerYaw;    // last player yaw for rotation tracking
	float grabLastPlayerPitch;  // last player pitch for rotation tracking (gesture mode)
	float grabAccumPitch;       // accumulated true pitch (unbounded, gimbal-safe display)
	float grabAccumYaw;         // accumulated true yaw (unbounded)
	float grabAccumRoll;        // accumulated true roll (unbounded, preserved from grab)
	int grabNewPhys;            // for freeze prop for prop

	// Props
	gentity_t* lastPlayer;  // for damage and killfeed
	int sb_phys;
	float sb_mass;

	// Ragdoll
	bool ragdollBone;  // bone entity of a ragdoll (s.ragdollID / s.boneID say which)
};

typedef enum { CON_DISCONNECTED, CON_CONNECTING, CON_CONNECTED } clientConnected_t;

// client data that stays across multiple respawns, but is cleared
// on each level change or team change at ClientBegin()
typedef struct {
	clientConnected_t connected;
	usercmd_t cmd;     // we would lose angles if not persistant
	bool localClient;  // true if "ip" info key is "localhost"
	char netname[MAX_NETNAME];
} clientPersistant_t;

// this structure is cleared on each ClientSpawn(),
// except for 'client->pers'
struct gclient_s {
	playerState_t ps;         // communicated by server to clients
	clientPersistant_t pers;  // the rest of the structure is private to game

	bool noclip;

	int buttons;

	vec3_t oldOrigin;

	// timers
	int respawnTime;         // can respawn when time > this, force after g_forcerespwan
	int inactivityTime;      // kick players when time > this
	bool inactivityWarning;  // true if the five seoond warning has been given

	int airOutTime;

	int timeResidual;

	bool ragdollDeath;  // a ragdoll was spawned at death and replaces the body-que corpse
};

//
// this structure is cleared as each map is entered
//
#define MAX_SPAWN_VARS 64
#define MAX_SPAWN_VARS_CHARS 4096

typedef struct {
	struct gclient_s* clients;  // [maxclients]
	struct gentity_s* gentities;
	int num_entities;  // MAX_CLIENTS <= num_entities <= ENTITYNUM_MAX_NORMAL

	// store latched cvars here that we want to get at often
	int maxclients;

	int framenum;
	int time;          // in msec
	int previousTime;  // so movers can back up when blocked

	int startTime;  // level.time the map was started

	bool restarted;  // waiting for a map_restart to fire

	// spawn variables
	bool spawning;  // the G_Spawn*() functions are valid
	int numSpawnVars;
	char* spawnVars[MAX_SPAWN_VARS][2];  // key / value pairs
	int numSpawnVarChars;
	char spawnVarChars[MAX_SPAWN_VARS_CHARS];

	int bodyQueIndex;  // dead bodies
	gentity_t* bodyQue[BODY_QUEUE_SIZE];
} level_locals_t;

//
// g_spawn.c
//
bool G_SpawnString(const char* key, const char* defaultString, char** out);
// spawn string returns a temporary reference, you must CopyString() if you want to keep it
bool G_SpawnFloat(const char* key, const char* defaultString, float* out);
bool G_SpawnInt(const char* key, const char* defaultString, int* out);
bool G_SpawnVector(const char* key, const char* defaultString, float* out);
void G_SpawnEntitiesFromString(void);
char* G_NewString(const char* string);

//
// g_cmds.c
//
void Cmd_Score_f(gentity_t* ent);

//
// g_items.c
//
void G_RunItem(gentity_t* ent);
void RespawnItem(gentity_t* ent);

gentity_t* Drop_Item(gentity_t* ent, item_t* item);
gentity_t* LaunchItem(item_t* item, vec3_t origin, vec3_t velocity);
void G_SpawnItem(gentity_t* ent, item_t* item);
void FinishSpawningItem(gentity_t* ent);
void Add_Ammo(gentity_t* ent, int weapon, int count);
void Touch_Item(gentity_t* ent, gentity_t* other, trace_t* trace);

//
// g_utils.c
//
int G_ModelIndex(char* name);
int G_SoundIndex(char* name);
void G_KillBox(gentity_t* ent);
gentity_t* G_Find(gentity_t* from, int fieldofs, const char* match);
gentity_t* G_PickTarget(char* targetname);
void G_UseTargets(gentity_t* ent, gentity_t* activator);
void G_SetMovedir(vec3_t angles, vec3_t movedir);

void G_InitGentity(gentity_t* e);
gentity_t* G_Spawn(void);
gentity_t* G_TempEntity(vec3_t origin, int event, int eventParm);
void G_Sound(gentity_t* ent, int channel, int soundIndex);
void G_FreeEntity(gentity_t* e);

void G_TouchTriggers(gentity_t* ent);

char* vtos(const vec3_t v);

void G_AddPredictableEvent(gentity_t* ent, int event, int eventParm);
void G_AddEvent(gentity_t* ent, int event, int eventParm);
void G_SetOrigin(gentity_t* ent, vec3_t origin);

gentity_t* FindEntityForPhysgun(gentity_t* ent, int range);
gentity_t* FindEntityForGravitygun(gentity_t* ent, int range);
void CrosshairPointPhys(gentity_t* ent, int range, vec3_t outPoint);
void CrosshairPointGravity(gentity_t* ent, int range, vec3_t outPoint);
bool G_PlayerIsOwner(gentity_t* player, gentity_t* ent);

//
// g_combat.c
//
bool CanDamage(gentity_t* targ, vec3_t origin);
void G_Damage(gentity_t* targ, gentity_t* inflictor, gentity_t* attacker, vec3_t dir, vec3_t point, int damage, int dflags, int mod);
void G_RadiusDamage(vec3_t origin, gentity_t* attacker, float damage, float radius, gentity_t* ignore, int mod);
void body_die(gentity_t* self, gentity_t* inflictor, gentity_t* attacker, int damage, int meansOfDeath);
void TossClientItems(gentity_t* self);

// damage flags
#define DAMAGE_RADIUS 0x00000001         // damage was indirect
#define DAMAGE_NO_ARMOR 0x00000002       // armour does not protect from this damage
#define DAMAGE_NO_KNOCKBACK 0x00000004   // do not affect velocity, just view angles
#define DAMAGE_NO_PROTECTION 0x00000008  // armor, shields, invulnerability, and godmode have no effect

//
// g_mover.c
//
void G_RunMover(gentity_t* ent);
void Touch_DoorTrigger(gentity_t* ent, gentity_t* other, trace_t* trace);

// g_physics.c
void Phys_HoldDropStatic(gentity_t* player, vec3_t velocity);
void Phys_HoldDropDynamic(gentity_t* player, vec3_t velocity, bool isPhysgun);
void Phys_HoldSetup(gentity_t* player, bool isPhysgun);
void Phys_HoldFrame_Kinetic(gentity_t* player, bool isPhysgun);
void Phys_HoldFrame(gentity_t* player, vec3_t velocity, bool isPhysgun);
void G_RunPhysics(gentity_t* ent);

//
// g_trigger.c
//
void trigger_teleporter_touch(gentity_t* self, gentity_t* other, trace_t* trace);

//
// g_misc.c
//
void TeleportPlayer(gentity_t* player, vec3_t origin, vec3_t angles);

// g_weapon.c
void CalcMuzzlePoint(gentity_t* ent, vec3_t forward, vec3_t right, vec3_t up, vec3_t muzzlePoint);
void G_ExplodeMissile(gentity_t* ent);
void G_RunMissile(gentity_t* ent);
gentity_t* fire_missile(gentity_t* self, vec3_t start, vec3_t forward, vec3_t right, vec3_t up, int weapon);
void FireWeapon(gentity_t* ent);

//
// g_client.c
//
void SetClientViewAngle(gentity_t* ent, vec3_t angle);
gentity_t* SelectSpawnPoint(vec3_t avoidPoint, vec3_t origin, vec3_t angles, bool isbot);
void CopyToBodyQue(gentity_t* ent);
void ClientRespawn(gentity_t* ent);
void InitBodyQue(void);
void ClientSpawn(gentity_t* ent);
void player_die(gentity_t* self, gentity_t* inflictor, gentity_t* attacker, int damage, int mod);
bool SpotWouldTelefrag(gentity_t* spot);

//
// vm_javascript.c (game vm js api)
//
// npcs spawned through GAPI_NPCSpawn are remembered so they can be removed
// on death instead of respawning (see ClientThink_real)
bool JS_IsJSSpawnedNPC(int clientNum);
void JS_ClearJSSpawnedNPC(int clientNum);
void JS_ClearAllSpawnedNPCs(void);

//
// g_svcmds.c
//
bool ConsoleCommand(void);

//
// g_weapon.c
//
void FireWeapon(gentity_t* ent);

//
// g_cmds.c
//
void DeathmatchScoreboardMessage(gentity_t* ent);
void G_SendSwepWeapons(gentity_t* ent);
void G_SendSpawnSwepWeapons(gentity_t* ent);

//
// g_main.c
//
void G_RunThink(gentity_t* ent);
void QDECL G_Printf(const char* fmt, ...) Q_PRINTF_FUNC(1, 2);
void QDECL G_Error(const char* fmt, ...) Q_NO_RETURN Q_PRINTF_FUNC(1, 2);

//
// g_client.c
//
char* ClientConnect(int clientNum, bool firstTime, bool isBot);
void ClientUserinfoChanged(int clientNum);
void ClientUpdateGrabbedConfigstring(gentity_t* ent);
void ClientDisconnect(int clientNum);
void ClientBegin(int clientNum);
void ClientCommand(int clientNum);

//
// g_active.c
//
void ClientThink(int clientNum);
void ClientEndFrame(gentity_t* ent);
void G_RunClient(gentity_t* ent);
bool G_CheckWeapon(int clientNum, int wp, int finish);
int G_CheckWeaponAmmo(int clientNum, int wp);
void PM_Add_SwepAmmo(int clientNum, int wp, int count);

//
// g_mem.c
//
void* G_Alloc(int size);
void G_InitMemory(void);

//
// g_bot.c
//
bool G_BotConnect(int clientNum, bool restart);
void Svcmd_AddBot_f(void);

// ai_main.c
#define MAX_FILEPATH 144

// bot settings
typedef struct bot_settings_s {
	float skill;
} bot_settings_t;

int BotAISetup(int restart);
int BotAIShutdown(int restart);
int BotAILoadMap(int restart);
int BotAISetupClient(int client, struct bot_settings_s* settings, bool restart);
int BotAIShutdownClient(int client, bool restart);
int BotAIStartFrame(int time);

extern level_locals_t level;
extern gentity_t g_entities[MAX_GENTITIES];

#define FOFS(x) ((size_t)&(((gentity_t*)0)->x))

extern vmCvar_t g_dedicated;
extern vmCvar_t g_cheats;
extern vmCvar_t g_maxclients;  // allow this many total, including spectators

extern vmCvar_t g_password;
extern vmCvar_t g_needpass;
extern vmCvar_t g_gravity;
extern vmCvar_t g_speed;
extern vmCvar_t g_knockback;
extern vmCvar_t g_inactivity;

void trap_LocateGameData(gentity_t* gEnts, int numGEntities, int sizeofGEntity_t, playerState_t* gameClients, int sizeofGameClient);
void trap_DropClient(int clientNum, const char* reason);
void trap_SendServerCommand(int clientNum, const char* text);
void trap_SetConfigstring(int num, const char* string);
void trap_GetConfigstring(int num, char* buffer, int bufferSize);
void trap_GetUserinfo(int num, char* buffer, int bufferSize);
void trap_SetUserinfo(int num, const char* buffer);
void trap_GetServerinfo(char* buffer, int bufferSize);
void trap_SetBrushModel(gentity_t* ent, const char* name);
void trap_Trace(trace_t* results, const vec3_t start, const vec3_t mins, const vec3_t maxs, const vec3_t end, int passEntityNum, int contentmask);
int trap_PointContents(const vec3_t point, int passEntityNum);
bool trap_InPVS(const vec3_t p1, const vec3_t p2);
bool trap_InPVSIgnorePortals(const vec3_t p1, const vec3_t p2);
void trap_AdjustAreaPortalState(gentity_t* ent, bool open);
bool trap_AreasConnected(int area1, int area2);
void trap_LinkEntity(gentity_t* ent);
void trap_UnlinkEntity(gentity_t* ent);
int trap_EntitiesInBox(const vec3_t mins, const vec3_t maxs, int* entityList, int maxcount);
bool trap_EntityContact(const vec3_t mins, const vec3_t maxs, const gentity_t* ent);
int trap_BotAllocateClient(void);
void trap_BotFreeClient(int clientNum);
void trap_GetUsercmd(int clientNum, usercmd_t* cmd);
bool trap_GetEntityToken(char* buffer, int bufferSize);

void trap_Phys_CreateShape(int modelindex, const char* objPath);
void trap_Phys_CreateModel(int entityID, int modelindex, float x, float y, float z, float mass);
void trap_Phys_DeleteObject(int entityID);
void trap_Phys_GetPosition(int entityID, float* x, float* y, float* z);
void trap_Phys_SetPosition(int entityID, float x, float y, float z);
void trap_Phys_GetAngles(int entityID, float* pitch, float* yaw, float* roll);
void trap_Phys_SetAngles(int entityID, float pitch, float yaw, float roll);
void trap_Phys_GetLinearVelocity(int entityID, float* vx, float* vy, float* vz);
void trap_Phys_SetLinearVelocity(int entityID, float vx, float vy, float vz);
void trap_Phys_GetAngularVelocity(int entityID, float* vx, float* vy, float* vz);
void trap_Phys_SetAngularVelocity(int entityID, float vx, float vy, float vz);
void trap_Phys_ApplyCentralForce(int entityID, float fx, float fy, float fz);
void trap_Phys_FreezeObject(int entityID);
void trap_Phys_UnfreezeObject(int entityID);
void trap_Phys_Weld(int entA, int entB, float px, float py, float pz);
bool trap_Phys_IsSleeping(int entityID);
void trap_Phys_CreateCapsule(int entityID, const physCapsuleDef_t* def);
void trap_Phys_CreateConeTwist(const physConeTwistDef_t* def);
void trap_Phys_IgnoreCollisionGroup(const int* entityIDs, int count);
void trap_LocateRagdollData(ragdollState_t* states, int numStates);
bool trap_Ragdoll_LoadSkeleton(const char* modelPath, const char* animPath, int frame, ragdollSkeleton_t* out);

//
// g_ragdoll.c
//
int G_SpawnRagdoll(const vec3_t origin, float yaw, const char* model, int playerid, int type, int lifetime);
void G_RemoveRagdoll(int id);
void G_RemoveAllRagdolls(void);
void G_InitRagdolls(void);
void G_RunRagdolls(void);
void G_RagdollBoneUpdate(gentity_t* ent, const vec3_t angles);
void G_RagdollEntityFreed(gentity_t* ent);
bool G_RagdollModelOfPlayer(int clientNum, char* out, int outSize);
void Cmd_Ragdoll_f(gentity_t* ent);
void Cmd_RagdollClear_f(gentity_t* ent);

int trap_BotLibSetup(void);
int trap_BotLibShutdown(void);
int trap_BotLibVarSet(char* var_name, char* value);
int trap_BotLibStartFrame(float time);
int trap_BotLibLoadMap(const char* mapname);
int trap_BotLibUpdateEntity(int ent, void /* struct bot_updateentity_s */* bue);

void trap_BotUserCommand(int client, usercmd_t* ucmd);

int trap_AAS_BBoxAreas(vec3_t absmins, vec3_t absmaxs, int* areas, int maxareas);
int trap_AAS_AreaInfo(int areanum, void /* struct aas_areainfo_s */* info);
void trap_AAS_EntityInfo(int entnum, void /* struct aas_entityinfo_s */* info);

int trap_AAS_Initialized(void);
void trap_AAS_PresenceTypeBoundingBox(int presencetype, vec3_t mins, vec3_t maxs);
float trap_AAS_Time(void);

int trap_AAS_PointAreaNum(vec3_t point);
int trap_AAS_TraceAreas(vec3_t start, vec3_t end, int* areas, vec3_t* points, int maxareas);

int trap_AAS_PointContents(vec3_t point);
int trap_AAS_NextBSPEntity(int ent);
int trap_AAS_ValueForBSPEpairKey(int ent, char* key, char* value, int size);
int trap_AAS_VectorForBSPEpairKey(int ent, char* key, vec3_t v);
int trap_AAS_FloatForBSPEpairKey(int ent, char* key, float* value);
int trap_AAS_IntForBSPEpairKey(int ent, char* key, int* value);

int trap_AAS_AreaReachability(int areanum);

int trap_AAS_AreaTravelTimeToGoalArea(int areanum, vec3_t origin, int goalareanum, int travelflags);
int trap_AAS_EnableRoutingArea(int areanum, int enable);
int trap_AAS_PredictRoute(void /*struct aas_predictroute_s*/* route, int areanum, vec3_t origin, int goalareanum, int travelflags, int maxareas, int maxtime, int stopevent, int stopcontents, int stoptfl, int stopareanum);

int trap_AAS_Swimming(vec3_t origin);
int trap_AAS_PredictClientMovement(void /* aas_clientmove_s */* move, int entnum, vec3_t origin, int presencetype, int onground, vec3_t velocity, vec3_t cmdmove, int cmdframes, int maxframes, float frametime, int stopevent, int stopareanum, int visualize);

void trap_EA_Attack(int client);
void trap_EA_Respawn(int client);
void trap_EA_SelectWeapon(int client, int weapon);
void trap_EA_View(int client, vec3_t viewangles);
void trap_EA_GetInput(int client, float thinktime, void /* struct bot_input_s */* input);
void trap_EA_ResetInput(int client);

int trap_BotGetServerCommand(int client, char* message, int size);
int trap_BotTouchingGoal(vec3_t origin, void /* struct bot_goal_s */* goal);

void trap_BotResetMoveState(int movestate);
void trap_BotMoveToGoal(void /* struct bot_moveresult_s */* result, int movestate, void /* struct bot_goal_s */* goal, int travelflags);
int trap_BotMoveInDirection(int movestate, vec3_t dir, float speed, int type);
void trap_BotResetAvoidReach(int movestate);
void trap_BotResetLastAvoidReach(int movestate);
int trap_BotMovementViewTarget(int movestate, void /* struct bot_goal_s */* goal, int travelflags, float lookahead, vec3_t target);
int trap_BotPredictVisiblePosition(vec3_t origin, int areanum, void /* struct bot_goal_s */* goal, int travelflags, vec3_t target);
int trap_BotAllocMoveState(void);
void trap_BotFreeMoveState(int handle);
void trap_BotInitMoveState(int handle, void /* struct bot_initmove_s */* initmove);
void trap_BotAddAvoidSpot(int movestate, vec3_t origin, float radius, int type);
