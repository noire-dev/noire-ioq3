/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
//
// g_combat.c

#include "../qcommon/vm_javascript.h"

/*
=================
TossClientItems

Toss the weapon and powerups for the killed player
=================
*/
void TossClientItems(gentity_t* self) {
	item_t* item;
	gentity_t* drop;

	// drop all weapons
	for(int i = 1; i < jsd_weaponCount; i++) {
		if(self->swep_list[i] >= WS_HAVE) {
			item = BG_FindItemForWeapon(i);
			if(!item) continue;
			drop = Drop_Item(self, item);
			drop->count = (self->swep_ammo[i]);
			if(drop->count < 1) drop->count = 1;
		}
	}
}

/*
==================
body_die
==================
*/
void body_die(gentity_t* self, gentity_t* inflictor, gentity_t* attacker, int damage, int meansOfDeath) {}

/*
==================
player_die
==================
*/
void player_die(gentity_t* self, gentity_t* inflictor, gentity_t* attacker, int damage, int meansOfDeath) {
	gentity_t* ent;
	int anim;
	int killer;
	int hookKiller;
	int i;
	char model[MAX_QPATH];

	if(self->client->ps.pm_type == PM_DEAD) return;
	self->client->ps.pm_type = PM_DEAD;

	if(attacker)
		killer = attacker->s.number;
	else
		killer = ENTITYNUM_WORLD;

	// js hook: playerDeath(victim, attacker, method)
	// attacker is -1 when killed by the world (falling, lava, crush, ...)
	hookKiller = killer;
	if(hookKiller >= ENTITYNUM_WORLD) hookKiller = -1;
	JS_HookRun("playerDeath", self->s.number, hookKiller, meansOfDeath);

	// broadcast the death event to everyone
	ent = G_TempEntity(self->r.currentOrigin, EV_OBITUARY, meansOfDeath);
	ent->s.otherEntityNum = killer;
	ent->s.otherEntityNum2 = self->s.number;
	ent->r.svFlags = SVF_BROADCAST;  // send to everyone

	self->enemy = attacker;

	TossClientItems(self);

	Cmd_Score_f(self);  // show scores

	self->takedamage = true;

	self->s.weapon = WP_NONE;
	self->r.contents = CONTENTS_CORPSE;

	self->s.angles[0] = 0;
	self->s.angles[2] = 0;

	VectorCopy(self->s.angles, self->client->ps.viewangles);

	self->s.loopSound = 0;

	self->r.maxs[2] = DEAD_HEIGHT;

	self->client->respawnTime = level.time + 1700;

	self->die = body_die;

	if(G_RagdollModelOfPlayer(self->s.number, model, sizeof(model))) {
		vec3_t origin;
		VectorCopy(self->client->ps.origin, origin);
		origin[2] += MINS_Z;
		G_SpawnRagdoll(origin, self->client->ps.viewangles[YAW], model, self->s.number, RAGDOLL_SIMPLE, 30000);
		self->client->ps.eFlags |= EF_NODRAW;
	}

	trap_LinkEntity(self);
}

/*
================
CheckArmor
================
*/
int CheckArmor(gentity_t* ent, int damage, int dflags) {
	gclient_t* client;
	int save;
	int count;

	if(!damage) return 0;

	client = ent->client;

	if(!client) return 0;

	if(dflags & DAMAGE_NO_ARMOR) return 0;

	// armor
	count = client->ps.stats[STAT_ARMOR];
	save = ceil(damage * ARMOR_PROTECTION);
	if(save >= count) save = count;

	if(!save) return 0;

	client->ps.stats[STAT_ARMOR] -= save;

	return save;
}

/*
============
G_Damage

targ		entity that is being damaged
inflictor	entity that is causing the damage
attacker	entity that caused the inflictor to damage targ
    example: targ=monster, inflictor=rocket, attacker=player

dir			direction of the attack for knockback
point		point at which the damage is being inflicted, used for headshots
damage		amount of damage being inflicted
knockback	force to be applied against targ as a result of the damage

inflictor, attacker, dir, and point can be NULL for environmental effects

dflags		these flags are used to control how T_Damage works
    DAMAGE_RADIUS			damage was indirect (from a nearby explosion)
    DAMAGE_NO_ARMOR			armor does not protect from this damage
    DAMAGE_NO_KNOCKBACK		do not affect velocity, just view angles
    DAMAGE_NO_PROTECTION	kills godmode, armor, everything
============
*/

void G_Damage(gentity_t* targ, gentity_t* inflictor, gentity_t* attacker, vec3_t dir, vec3_t point, int damage, int dflags, int mod) {
	gclient_t* client;
	int take;
	int asave;
	int knockback;
	int hookAttacker;

	if(!targ->takedamage) {
		return;
	}

	if(!inflictor) {
		inflictor = &g_entities[ENTITYNUM_WORLD];
	}
	if(!attacker) {
		attacker = &g_entities[ENTITYNUM_WORLD];
	}

	// shootable doors / buttons don't actually have any health
	if(targ->s.eType == ET_MOVER) {
		if(targ->use && targ->moverState == MOVER_POS1) {
			targ->use(targ, inflictor, attacker);
		}
		return;
	}

	client = targ->client;

	if(client) {
		if(client->noclip) {
			return;
		}
	}

	if(!dir) {
		dflags |= DAMAGE_NO_KNOCKBACK;
	} else {
		VectorNormalize(dir);
	}

	knockback = damage;
	if(knockback > 200) {
		knockback = 200;
	}
	if(targ->flags & FL_NO_KNOCKBACK) {
		knockback = 0;
	}
	if(dflags & DAMAGE_NO_KNOCKBACK) {
		knockback = 0;
	}

	// figure momentum add, even if the damage won't be taken
	if((knockback && targ->client) || (knockback && targ->s.eType == ET_PHYSICS)) {
		vec3_t kvel;
		vec3_t kvel_angular;
		float mass;

		mass = 200;

		if(targ->s.eType == ET_PHYSICS) {
			VectorScale(dir, g_knockback.value * 3.00 * (float)knockback / mass, kvel);
			VectorScale(dir, g_knockback.value * 0.01 * (float)knockback / mass, kvel_angular);
		} else {
			VectorScale(dir, g_knockback.value * (float)knockback / mass, kvel);
		}
		if(targ->client) {
			VectorAdd(targ->client->ps.velocity, kvel, targ->client->ps.velocity);
		}
		if(targ->s.eType == ET_PHYSICS) {
			vec3_t newVelocity;
			vec3_t newAngularVelocity;
			targ->lastPlayer = attacker;
			trap_Phys_GetLinearVelocity(targ->s.number, &newVelocity[0], &newVelocity[1], &newVelocity[2]);
			VectorAdd(newVelocity, kvel, kvel);
			trap_Phys_SetLinearVelocity(targ->s.number, kvel[0], kvel[1], kvel[2]);
			trap_Phys_GetAngularVelocity(targ->s.number, &newAngularVelocity[0], &newAngularVelocity[1], &newAngularVelocity[2]);
			VectorAdd(newAngularVelocity, kvel_angular, kvel_angular);
			trap_Phys_SetAngularVelocity(targ->s.number, kvel_angular[0], kvel_angular[1], kvel_angular[2]);
		}

		// set the timer so that the other client can't cancel
		// out the movement immediately
		if(targ->s.eType != ET_PHYSICS) {
			if(!targ->client->ps.pm_time) {
				int t;

				t = knockback * 2;
				if(t < 50) {
					t = 50;
				}
				if(t > 200) {
					t = 200;
				}
				targ->client->ps.pm_time = t;
				targ->client->ps.pm_flags |= PMF_TIME_KNOCKBACK;
			}
		}
	}

	if(targ->s.eType == ET_PHYSICS && targ->health == -1) return;

	// check for completely getting out of the damage
	if(!(dflags & DAMAGE_NO_PROTECTION) && targ->flags & FL_GODMODE) return;

	// always give half damage if hurting self
	// calculated after knockback, so rocket jumping works
	if(targ == attacker) damage *= 0.5;
	if(damage < 1) damage = 1;

	take = damage;

	// save some from armor
	asave = CheckArmor(targ, take, dflags);
	take -= asave;

	// do the damage
	if(take) {
		targ->health = targ->health - take;
		if(targ->client) {
			targ->client->ps.stats[STAT_HEALTH] = targ->health;
		}

		// js hook: damage(victim, attacker, method)
		// victim is a player, npc or prop entity number, attacker is -1 for the world
		hookAttacker = attacker->s.number;
		if(hookAttacker >= ENTITYNUM_WORLD) hookAttacker = -1;
		JS_HookRun("damage", targ->s.number, hookAttacker, mod);

		if(targ->health <= 0) {
			if(client) targ->flags |= FL_NO_KNOCKBACK;

			if(targ->health < -999) targ->health = -999;

			targ->enemy = attacker;
			if(targ->die) targ->die(targ, inflictor, attacker, take, mod);
			return;
		} else if(targ->pain) {
			targ->pain(targ, attacker, take);
		}
	}
}

/*
============
CanDamage

Returns true if the inflictor can directly damage the target.  Used for
explosions and melee attacks.
============
*/
bool CanDamage(gentity_t* targ, vec3_t origin) {
	vec3_t dest;
	trace_t tr;
	vec3_t midpoint;
	vec3_t offsetmins = {-15, -15, -15};
	vec3_t offsetmaxs = {15, 15, 15};

	// use the midpoint of the bounds instead of the origin, because
	// bmodels may have their origin is 0,0,0
	VectorAdd(targ->r.absmin, targ->r.absmax, midpoint);
	VectorScale(midpoint, 0.5, midpoint);

	VectorCopy(midpoint, dest);
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0 || tr.entityNum == targ->s.number) return true;

	// this should probably check in the plane of projection,
	// rather than in world coordinate
	VectorCopy(midpoint, dest);
	dest[0] += offsetmaxs[0];
	dest[1] += offsetmaxs[1];
	dest[2] += offsetmaxs[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmaxs[0];
	dest[1] += offsetmins[1];
	dest[2] += offsetmaxs[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmins[0];
	dest[1] += offsetmaxs[1];
	dest[2] += offsetmaxs[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmins[0];
	dest[1] += offsetmins[1];
	dest[2] += offsetmaxs[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmaxs[0];
	dest[1] += offsetmaxs[1];
	dest[2] += offsetmins[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmaxs[0];
	dest[1] += offsetmins[1];
	dest[2] += offsetmins[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmins[0];
	dest[1] += offsetmaxs[1];
	dest[2] += offsetmins[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	VectorCopy(midpoint, dest);
	dest[0] += offsetmins[0];
	dest[1] += offsetmins[1];
	dest[2] += offsetmins[2];
	trap_Trace(&tr, origin, vec3_origin, vec3_origin, dest, ENTITYNUM_NONE, MASK_SOLID);

	if(tr.fraction == 1.0) return true;

	return false;
}

/*
============
G_RadiusDamage
============
*/
void G_RadiusDamage(vec3_t origin, gentity_t* attacker, float damage, float radius, gentity_t* ignore, int mod) {
	float points, dist;
	gentity_t* ent;
	int entityList[MAX_GENTITIES];
	int numListedEntities;
	vec3_t mins, maxs;
	vec3_t v;
	vec3_t dir;
	int i, e;

	if(radius < 1) radius = 1;

	for(i = 0; i < 3; i++) {
		mins[i] = origin[i] - radius;
		maxs[i] = origin[i] + radius;
	}

	numListedEntities = trap_EntitiesInBox(mins, maxs, entityList, MAX_GENTITIES);

	for(e = 0; e < numListedEntities; e++) {
		ent = &g_entities[entityList[e]];

		if(ent == ignore) continue;
		if(!ent->takedamage) continue;

		// find the distance from the edge of the bounding box
		for(i = 0; i < 3; i++) {
			if(origin[i] < ent->r.absmin[i])
				v[i] = ent->r.absmin[i] - origin[i];
			else if(origin[i] > ent->r.absmax[i])
				v[i] = origin[i] - ent->r.absmax[i];
			else
				v[i] = 0;
		}

		dist = VectorLength(v);
		if(dist >= radius) continue;

		points = damage * (1.0 - dist / radius);

		if(CanDamage(ent, origin)) {
			VectorSubtract(ent->r.currentOrigin, origin, dir);
			dir[2] += 24;
			G_Damage(ent, NULL, attacker, dir, origin, (int)points, DAMAGE_RADIUS, mod);
		}
	}
}
