/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
//

#include "g_local.h"

/*
=============
P_WorldEffects

Check for lava / slime contents and drowning
=============
*/
void P_WorldEffects(gentity_t* ent) {
	int waterlevel;

	if(ent->client->noclip) {
		ent->client->airOutTime = level.time + 12000;  // don't need air
		return;
	}

	waterlevel = ent->waterlevel;

	//
	// check for drowning
	//
	if(waterlevel == 3) {
		// if out of air, start drowning
		if(ent->client->airOutTime < level.time) {
			// drown!
			ent->client->airOutTime += 1000;
			if(ent->health > 0) {
				// take more damage the longer underwater
				ent->damage += 2;
				if(ent->damage > 15) ent->damage = 15;

				// don't play a normal pain sound
				ent->pain_debounce_time = level.time + 200;

				G_Damage(ent, NULL, NULL, NULL, NULL, ent->damage, DAMAGE_NO_ARMOR, MOD_WATER);
			}
		}
	} else {
		ent->client->airOutTime = level.time + 12000;
		ent->damage = 2;
	}

	//
	// check for sizzle damage (move to pmove?)
	//
	if(waterlevel && (ent->watertype & (CONTENTS_LAVA | CONTENTS_SLIME))) {
		if(ent->health > 0 && ent->pain_debounce_time <= level.time) {
			if(ent->watertype & CONTENTS_LAVA) {
				G_Damage(ent, NULL, NULL, NULL, NULL, 30 * waterlevel, 0, MOD_LAVA);
			}

			if(ent->watertype & CONTENTS_SLIME) {
				G_Damage(ent, NULL, NULL, NULL, NULL, 10 * waterlevel, 0, MOD_SLIME);
			}
		}
	}
}

/*
===============
G_SetClientSound
===============
*/
void G_SetClientSound(gentity_t* ent) {
	if(ent->waterlevel && (ent->watertype & (CONTENTS_LAVA | CONTENTS_SLIME))) {
		ent->client->ps.loopSound = G_SoundIndex("sound/player/fry.wav");
	} else {
		ent->client->ps.loopSound = 0;
	}
}

//==============================================================

/*
==============
ClientImpacts
==============
*/
void ClientImpacts(gentity_t* ent, pmove_t* pm) {
	int i, j;
	trace_t trace;
	gentity_t* other;

	memset(&trace, 0, sizeof(trace));
	for(i = 0; i < pm->numtouch; i++) {
		for(j = 0; j < i; j++) {
			if(pm->touchents[j] == pm->touchents[i]) {
				break;
			}
		}
		if(j != i) {
			continue;  // duplicated
		}
		other = &g_entities[pm->touchents[i]];

		if((ent->r.svFlags & SVF_BOT) && (ent->touch)) {
			ent->touch(ent, other, &trace);
		}

		if(!other->touch) {
			continue;
		}

		other->touch(other, ent, &trace);
	}
}

/*
============
G_TouchTriggers
============
*/
void G_TouchTriggers(gentity_t* ent) {
	int i, num;
	int touch[MAX_GENTITIES];
	gentity_t* hit;
	trace_t trace;
	vec3_t mins, maxs;
	static vec3_t range = {40, 40, 52};

	if(!ent->client) {
		return;
	}

	// dead clients don't activate triggers!
	if(ent->client->ps.stats[STAT_HEALTH] <= 0) {
		return;
	}

	VectorSubtract(ent->client->ps.origin, range, mins);
	VectorAdd(ent->client->ps.origin, range, maxs);

	num = trap_EntitiesInBox(mins, maxs, touch, MAX_GENTITIES);

	// can't use ent->absmin, because that has a one unit pad
	VectorAdd(ent->client->ps.origin, ent->r.mins, mins);
	VectorAdd(ent->client->ps.origin, ent->r.maxs, maxs);

	for(i = 0; i < num; i++) {
		hit = &g_entities[touch[i]];

		if(!hit->touch && !ent->touch) {
			continue;
		}
		if(!(hit->r.contents & CONTENTS_TRIGGER)) {
			continue;
		}

		// use separate code for determining if an item is picked up
		// so you don't have to actually contact its bounding box
		if(hit->s.eType == ET_ITEM) {
			if(!BG_PlayerTouchesItem(&ent->client->ps, &hit->s, level.time)) {
				continue;
			}
		} else {
			if(!trap_EntityContact(mins, maxs, hit)) {
				continue;
			}
		}

		memset(&trace, 0, sizeof(trace));

		if(hit->touch) {
			hit->touch(hit, ent, &trace);
		}

		if((ent->r.svFlags & SVF_BOT) && (ent->touch)) {
			ent->touch(ent, hit, &trace);
		}
	}
}

/*
=================
ClientInactivityTimer

Returns false if the client is dropped
=================
*/
bool ClientInactivityTimer(gclient_t* client) {
	if(client->pers.cmd.forwardmove || client->pers.cmd.rightmove || client->pers.cmd.upmove || (client->pers.cmd.buttons & BUTTON_ATTACK)) {
		client->inactivityTime = level.time + g_inactivity.integer * 1000;
		client->inactivityWarning = false;
	} else if(!client->pers.localClient) {
		if(level.time > client->inactivityTime) {
			trap_DropClient(client - level.clients, "Dropped due to inactivity");
			return false;
		}
		if(level.time > client->inactivityTime - 15000 && !client->inactivityWarning) {
			client->inactivityWarning = true;
			trap_SendServerCommand(client - level.clients, "cp \"15 seconds until inactivity drop!\n\"");
		}
	}
	return true;
}

/*
==================
ClientTimerActions

Actions that happen once a second
==================
*/
void ClientTimerActions(gentity_t* ent, int msec) {
	gclient_t* client;

	client = ent->client;
	client->timeResidual += msec;

	while(client->timeResidual >= 1000) {
		client->timeResidual -= 1000;
		G_SendSwepWeapons(ent);  // send sweps list to client for sync
	}
}

/*
================
ClientEvents

Events will be passed on to the clients for presentation,
but any server game effects are handled here
================
*/
void ClientEvents(gentity_t* ent, int oldEventSequence) {
	int i;
	int event;
	gclient_t* client;
	int damage;

	client = ent->client;

	if(oldEventSequence < client->ps.eventSequence - MAX_PS_EVENTS) {
		oldEventSequence = client->ps.eventSequence - MAX_PS_EVENTS;
	}
	for(i = oldEventSequence; i < client->ps.eventSequence; i++) {
		event = client->ps.events[i & (MAX_PS_EVENTS - 1)];

		switch(event) {
			case EV_FALL:
				if(ent->s.eType != ET_PLAYER) {
					break;  // not in the player mode
					damage = 5;
				}
				ent->pain_debounce_time = level.time + 200;  // no normal pain sound
				G_Damage(ent, NULL, NULL, NULL, NULL, damage, 0, MOD_FALLING);
				break;

			case EV_FIRE_WEAPON: FireWeapon(ent); break;

			default: break;
		}
	}
}

void BotTestSolid(vec3_t origin);

/*
==============
SendPendingPredictableEvents
==============
*/
void SendPendingPredictableEvents(playerState_t* ps) {
	gentity_t* t;
	int event, seq;
	int extEvent, number;

	// if there are still events pending
	if(ps->entityEventSequence < ps->eventSequence) {
		// create a temporary entity for this event which is sent to everyone
		// except the client who generated the event
		seq = ps->entityEventSequence & (MAX_PS_EVENTS - 1);
		event = ps->events[seq] | ((ps->entityEventSequence & 3) << 8);
		// set external event to zero before calling BG_PlayerStateToEntityState
		extEvent = ps->externalEvent;
		ps->externalEvent = 0;
		// create temporary entity for event
		t = G_TempEntity(ps->origin, event, 0);
		number = t->s.number;
		BG_PlayerStateToEntityState(ps, &t->s, true);
		t->s.number = number;
		t->s.eType = ET_EVENTS + event;
		t->s.eFlags |= EF_PLAYER_EVENT;
		t->s.otherEntityNum = ps->clientNum;
		// send to everyone except the client who generated the event
		t->r.svFlags |= SVF_NOTSINGLECLIENT;
		t->r.singleClient = ps->clientNum;
		// set back external event
		ps->externalEvent = extEvent;
	}
}

static void PhysgunHold(gentity_t* player) {
	gentity_t* ent = player->grabbedEntity;
	gentity_t* findent;
	vec3_t velocity;

	if(jsd_weapon[player->client->ps.weapon].wType != WT_PHYSGUN) return;

	if(player->client->buttons & BUTTON_ATTACK && player->client->ps.stats[STAT_HEALTH] && player->client->ps.pm_type != PM_DEAD) {
		if(!player->grabbedEntity) {
			findent = FindEntityForPhysgun(player, jsd_weapon[player->client->ps.weapon].range);
			if(findent && findent->isGrabbed == false) {
				if(!G_PlayerIsOwner(player, findent)) return;
				if(findent) player->grabbedEntity = findent;
			}
			if(player->grabbedEntity) {
				Phys_HoldSetup(player, true);
				ClientUpdateGrabbedConfigstring(player);
			}
		} else {
			Phys_HoldFrame_Kinetic(player, true);
		}
	} else if(player->grabbedEntity) {
		ent->isGrabbed = false;
		if(ent->grabNewPhys == PHYS_STATIC) Phys_HoldDropStatic(player, velocity);
		if(ent->grabNewPhys == PHYS_DYNAMIC) Phys_HoldDropDynamic(player, velocity, true);
		VectorClear(player->grabOffset);
		player->grabbedEntity = 0;
		ClientUpdateGrabbedConfigstring(player);
		if(ent->ragdollBone) ent->r.svFlags |= SVF_NOCLIENT;
	}
}

static void GravitygunHold(gentity_t* player) {
	gentity_t* ent = player->grabbedEntity;
	gentity_t* findent;
	vec3_t velocity;

	if(jsd_weapon[player->client->ps.weapon].wType != WT_GRAVITYGUN) return;

	if(player->client->buttons & BUTTON_ATTACK && player->client->ps.stats[STAT_HEALTH] && player->client->ps.pm_type != PM_DEAD) {
		if(!player->grabbedEntity) {
			findent = FindEntityForGravitygun(player, jsd_weapon[player->client->ps.weapon].range);
			if(findent && findent->isGrabbed == false) {
				if(!G_PlayerIsOwner(player, findent)) return;
				if(findent) player->grabbedEntity = findent;
			}
			if(player->grabbedEntity) {
				Phys_HoldSetup(player, false);
				ClientUpdateGrabbedConfigstring(player);
			}
		} else {
			Phys_HoldFrame_Kinetic(player, false);
		}
	} else if(player->grabbedEntity) {
		ent->isGrabbed = false;
		Phys_HoldDropDynamic(player, velocity, false);
		player->grabbedEntity = 0;
		ClientUpdateGrabbedConfigstring(player);
		G_AddEvent(player, EV_GRAVITY_LAUNCH, 0);
		if(ent->ragdollBone) ent->r.svFlags |= SVF_NOCLIENT;
	}
}

/*
==============
ClientThink

This will be called once for each client frame, which will
usually be a couple times for each server frame on fast clients.
==============
*/
void ClientThink_real(gentity_t* ent) {
	gclient_t* client;
	pmove_t pm;
	int oldEventSequence;
	int msec;
	usercmd_t* ucmd;

	client = ent->client;

	// don't think if the client is not yet connected (and thus not yet spawned in)
	if(client->pers.connected != CON_CONNECTED) {
		return;
	}
	// mark the time, so the connection sprite can be removed
	ucmd = &ent->client->pers.cmd;

	// sanity check the command time to prevent speedup cheating
	if(ucmd->serverTime > level.time + 200) {
		ucmd->serverTime = level.time + 200;
		//		G_Printf("serverTime <<<<<\n" );
	}
	if(ucmd->serverTime < level.time - 1000) {
		ucmd->serverTime = level.time - 1000;
		//		G_Printf("serverTime >>>>>\n" );
	}

	msec = ucmd->serverTime - client->ps.commandTime;
	// following others may result in bad times, but we still want
	// to check for follow toggles
	if(msec < 1) return;
	if(msec > 200) msec = 200;

	// check for inactivity timer, but never drop the local client of a non-dedicated server
	if(!ClientInactivityTimer(client)) return;

	if(client->noclip) {
		client->ps.pm_type = PM_NOCLIP;
	} else if(client->ps.stats[STAT_HEALTH] <= 0) {
		client->ps.pm_type = PM_DEAD;
	} else {
		client->ps.pm_type = PM_NORMAL;
	}

	client->ps.stats[STAT_AMMO] = ent->swep_ammo[client->ps.weapon];

	client->ps.gravity = g_gravity.value;

	// set speed
	client->ps.speed = g_speed.value;

	// set up for pmove
	oldEventSequence = client->ps.eventSequence;

	memset(&pm, 0, sizeof(pm));

	pm.ps = &client->ps;
	pm.cmd = *ucmd;
	if(pm.ps->pm_type == PM_DEAD) {
		pm.tracemask = MASK_PLAYERSOLID & ~CONTENTS_BODY;
	} else if(ent->r.svFlags & SVF_BOT) {
		pm.tracemask = MASK_PLAYERSOLID | CONTENTS_BOTCLIP;
	} else {
		pm.tracemask = MASK_PLAYERSOLID;
	}
	pm.trace = trap_Trace;
	pm.pointcontents = trap_PointContents;

	Pmove(&pm);

	// save results of pmove
	if(ent->client->ps.eventSequence != oldEventSequence) ent->eventTime = level.time;

	BG_PlayerStateToEntityStateExtraPolate(&ent->client->ps, &ent->s, ent->client->ps.commandTime, true);
	SendPendingPredictableEvents(&ent->client->ps);

	// use the snapped origin for linking so it matches client predicted versions
	VectorCopy(ent->s.pos.trBase, ent->r.currentOrigin);

	VectorCopy(pm.mins, ent->r.mins);
	VectorCopy(pm.maxs, ent->r.maxs);

	ent->waterlevel = pm.waterlevel;
	ent->watertype = pm.watertype;

	// execute client events
	ClientEvents(ent, oldEventSequence);

	// link entity now, after any personal teleporters have been used
	trap_LinkEntity(ent);
	if(!ent->client->noclip) G_TouchTriggers(ent);

	// NOTE: now copy the exact origin over otherwise clients can be snapped into solid
	VectorCopy(ent->client->ps.origin, ent->r.currentOrigin);

	// touch other objects
	ClientImpacts(ent, &pm);

	// save results of triggers and client events
	if(ent->client->ps.eventSequence != oldEventSequence) ent->eventTime = level.time;

	// swap and latch button actions
	client->buttons = ucmd->buttons;

	PhysgunHold(ent);
	GravitygunHold(ent);

	// check for respawning
	if(client->ps.stats[STAT_HEALTH] <= 0) {
		if(level.time > client->respawnTime) {
			// npcs spawned through the js api are removed once their death
			// animation has played instead of respawning
			if(JS_IsJSSpawnedNPC(ent->s.number)) {
				JS_ClearJSSpawnedNPC(ent->s.number);
				trap_DropClient(ent->s.number, "NPC removed");
				return;
			}
			if(ucmd->buttons & BUTTON_ATTACK) ClientRespawn(ent);
		}
		return;
	}

	// perform once-a-second actions
	ClientTimerActions(ent, msec);
}

/*
==================
ClientThink

A new command has arrived from the client
==================
*/
void ClientThink(int clientNum) {
	gentity_t* ent;

	ent = g_entities + clientNum;
	trap_GetUsercmd(clientNum, &ent->client->pers.cmd);

	if(!(ent->r.svFlags & SVF_BOT)) ClientThink_real(ent);
}

void G_RunClient(gentity_t* ent) {
	if(!(ent->r.svFlags & SVF_BOT)) return;
	ent->client->pers.cmd.serverTime = level.time;
	ClientThink_real(ent);
}

/*
==============
ClientEndFrame

Called at the end of each server frame for each connected client
A fast client will have multiple ClientThink for each ClientEdFrame,
while a slow client may have multiple ClientEndFrame between ClientThink.
==============
*/
void ClientEndFrame(gentity_t* ent) {
	// burn from lava, etc
	P_WorldEffects(ent);

	ent->client->ps.stats[STAT_HEALTH] = ent->health;  // FIXME: get rid of ent->health...

	G_SetClientSound(ent);

	// set the latest infor
	BG_PlayerStateToEntityStateExtraPolate(&ent->client->ps, &ent->s, ent->client->ps.commandTime, true);
	SendPendingPredictableEvents(&ent->client->ps);
}

bool G_CheckWeapon(int clientNum, int wp, int finish) {
	gentity_t* ent = g_entities + clientNum;

	if(ent->swep_list[wp] >= WS_HAVE) {
		if(finish) ent->client->ps.weapon = wp;
		return true;
	}
	return false;
}

int G_CheckWeaponAmmo(int clientNum, int wp) {
	gentity_t* ent;

	ent = g_entities + clientNum;
	return ent->swep_ammo[wp];
}

void PM_Add_SwepAmmo(int clientNum, int wp, int count) {
	gentity_t* ent;

	ent = g_entities + clientNum;
	if(!(ent->swep_ammo[wp] == -1)) {
		if(!(ent->swep_ammo[wp] >= 9999)) {
			ent->swep_ammo[wp] += count;
		}
	}
}
