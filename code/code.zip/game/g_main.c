/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
//

#include "../qcommon/vm_javascript.h"

level_locals_t level;

typedef struct {
	vmCvar_t* vmCvar;
	char* cvarName;
	char* defaultString;
	int cvarFlags;
	int modificationCount;  // for tracking changes
	bool trackChange;       // track this variable, and announce if changed
} cvarTable_t;

gentity_t g_entities[MAX_GENTITIES];
gclient_t g_clients[MAX_CLIENTS];

vmCvar_t g_password;
vmCvar_t g_needpass;
vmCvar_t g_maxclients;
vmCvar_t g_dedicated;
vmCvar_t g_speed;
vmCvar_t g_gravity;
vmCvar_t g_cheats;
vmCvar_t g_knockback;
vmCvar_t g_inactivity;
vmCvar_t g_listEntity;

static cvarTable_t gameCvarTable[] = {// don't override the cheat state set by the system
                                      {&g_cheats, "sv_cheats", "", 0, 0, false},

                                      // noset vars
                                      {NULL, "gamename", GAMEVERSION, CVAR_SERVERINFO | CVAR_ROM, 0, false},
                                      {NULL, "gamedate", PRODUCT_DATE, CVAR_ROM, 0, false},

                                      {&g_maxclients, "sv_maxclients", "8", CVAR_SERVERINFO | CVAR_LATCH | CVAR_ARCHIVE, 0, false},

                                      // change anytime vars
                                      {&g_password, "g_password", "", CVAR_USERINFO, 0, false},
                                      {&g_needpass, "g_needpass", "0", CVAR_SERVERINFO | CVAR_ROM, 0, false},
                                      {&g_dedicated, "dedicated", "0", 0, 0, false},
                                      {&g_speed, "g_speed", "280", 0, 0, true},
                                      {&g_gravity, "g_gravity", "800", 0, 0, true},
                                      {&g_knockback, "g_knockback", "1000", 0, 0, true},
                                      {&g_inactivity, "g_inactivity", "60", 0, 0, true},

                                      {&g_listEntity, "g_listEntity", "0", 0, 0, false}

};

static int gameCvarTableSize = ARRAY_LEN(gameCvarTable);

void G_InitGame(int levelTime, int randomSeed, int restart);
void G_RunFrame(int levelTime);
void G_ShutdownGame(int restart);

/*
================
vmMain

This is the only way control passes into the module.
This must be the very first function compiled into the .q3vm file
================
*/
Q_EXPORT intptr_t vmMain(int command, int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, int arg10, int arg11) {
	switch(command) {
		case GAME_INIT: G_InitGame(arg0, arg1, arg2); return 0;
		case GAME_SHUTDOWN: G_ShutdownGame(arg0); return 0;
		case GAME_CLIENT_CONNECT: return (intptr_t)ClientConnect(arg0, arg1, arg2);
		case GAME_CLIENT_THINK: ClientThink(arg0); return 0;
		case GAME_CLIENT_USERINFO_CHANGED: ClientUserinfoChanged(arg0); return 0;
		case GAME_CLIENT_DISCONNECT: ClientDisconnect(arg0); return 0;
		case GAME_CLIENT_BEGIN: ClientBegin(arg0); return 0;
		case GAME_CLIENT_COMMAND: ClientCommand(arg0); return 0;
		case GAME_RUN_FRAME: G_RunFrame(arg0); return 0;
		case GAME_CONSOLE_COMMAND: return ConsoleCommand();
		case BOTAI_START_FRAME: return BotAIStartFrame(arg0);

		case GETVMCONTEXT: VMContext(&vmargs, &vmresult); return 0;
		case VMCALL: VMCall(arg0); return 0;
		default: trap_Error("game.vm: unknown command"); break;
	}

	return -1;
}

void QDECL G_Printf(const char* fmt, ...) {
	va_list argptr;
	char text[1024];

	va_start(argptr, fmt);
	Q_vsnprintf(text, sizeof(text), fmt, argptr);
	va_end(argptr);

	trap_Print(text);
}

void QDECL G_Error(const char* fmt, ...) {
	va_list argptr;
	char text[1024];

	va_start(argptr, fmt);
	Q_vsnprintf(text, sizeof(text), fmt, argptr);
	va_end(argptr);

	trap_Error(text);
}

static void G_FindEntityTeams(void) {
	gentity_t *e, *e2;
	int i, j;
	int c, c2;

	c = 0;
	c2 = 0;
	for(i = MAX_CLIENTS, e = g_entities + i; i < level.num_entities; i++, e++) {
		if(!e->inuse) continue;
		if(!e->team) continue;
		if(e->flags & FL_TEAMMEMBER) continue;
		e->teammaster = e;
		c++;
		c2++;
		for(j = i + 1, e2 = e + 1; j < level.num_entities; j++, e2++) {
			if(!e2->inuse) continue;
			if(!e2->team) continue;
			if(e2->flags & FL_TEAMMEMBER) continue;
			if(!strcmp(e->team, e2->team)) {
				c2++;
				e2->teamchain = e->teamchain;
				e->teamchain = e2;
				e2->teammaster = e;
				e2->flags |= FL_TEAMMEMBER;

				// make sure that targets only point at the master
				if(e2->targetname) {
					e->targetname = e2->targetname;
					e2->targetname = NULL;
				}
			}
		}
	}

	G_Printf("%i teams with %i entities\n", c, c2);
}

void G_RegisterCvars(void) {
	int i;
	cvarTable_t* cv;

	for(i = 0, cv = gameCvarTable; i < gameCvarTableSize; i++, cv++) {
		trap_Cvar_Register(cv->vmCvar, cv->cvarName, cv->defaultString, cv->cvarFlags);
		if(cv->vmCvar) cv->modificationCount = cv->vmCvar->modificationCount;
	}
}

void G_UpdateCvars(void) {
	int i;
	cvarTable_t* cv;

	for(i = 0, cv = gameCvarTable; i < gameCvarTableSize; i++, cv++) {
		if(cv->vmCvar) {
			trap_Cvar_Update(cv->vmCvar);

			if(cv->modificationCount != cv->vmCvar->modificationCount) {
				cv->modificationCount = cv->vmCvar->modificationCount;

				if(cv->trackChange) {
					trap_SendServerCommand(-1, va("print \"Server: %s changed to %s\n\"", cv->cvarName, cv->vmCvar->string));
				}
			}
		}
	}
}

void G_InitGame(int levelTime, int randomSeed, int restart) {
	int i;

	G_Printf("------- Game Initialization -------\n");
	G_Printf("gamename: %s\n", GAMEVERSION);
	G_Printf("gamedate: %s\n", PRODUCT_DATE);

	srand(randomSeed);

	G_RegisterCvars();

	G_InitMemory();

	JS_SystemInit(VM_GAME);

	// set some level globals
	memset(&level, 0, sizeof(level));
	level.time = levelTime;
	level.startTime = levelTime;

	// no js-spawned npc survives a level change
	JS_ClearAllSpawnedNPCs();

	// initialize all entities for this game
	memset(g_entities, 0, MAX_GENTITIES * sizeof(g_entities[0]));
	level.gentities = g_entities;

	// initialize all clients for this game
	level.maxclients = g_maxclients.integer;
	memset(g_clients, 0, MAX_CLIENTS * sizeof(g_clients[0]));
	level.clients = g_clients;

	// set client fields on player ents
	for(i = 0; i < level.maxclients; i++) {
		g_entities[i].client = level.clients + i;
	}

	// always leave room for the max number of clients,
	// even if they aren't all used, so numbers inside that
	// range are NEVER anything but clients
	level.num_entities = MAX_CLIENTS;

	for(i = 0; i < MAX_CLIENTS; i++) {
		g_entities[i].classname = "clientslot";
	}

	// let the server system know where the entites are
	trap_LocateGameData(level.gentities, level.num_entities, sizeof(gentity_t), &level.clients[0].ps, sizeof(level.clients[0]));

	// ragdoll states (sent to clients by the server) and ragdoll slots
	G_InitRagdolls();

	// reserve some spots for dead player bodies
	InitBodyQue();

	// parse the key/value pairs and spawn gentities
	G_SpawnEntitiesFromString();

	// general initialization
	G_FindEntityTeams();

	G_Printf("-----------------------------------\n");

	if(trap_Cvar_VariableIntegerValue("bot_enable")) {
		BotAISetup(restart);
		BotAILoadMap(restart);
	}
}

/*
=================
G_ShutdownGame
=================
*/
void G_ShutdownGame(int restart) {
	G_Printf("==== ShutdownGame ====\n");

	if(trap_Cvar_VariableIntegerValue("bot_enable")) BotAIShutdown(restart);
}

//===================================================================

void QDECL Com_Error(int logLevel, const char* error, ...) {
	va_list argptr;
	char text[1024];

	va_start(argptr, error);
	Q_vsnprintf(text, sizeof(text), error, argptr);
	va_end(argptr);

	trap_Error(text);
}

void QDECL Com_Printf(const char* msg, ...) {
	va_list argptr;
	char text[1024];

	va_start(argptr, msg);
	Q_vsnprintf(text, sizeof(text), msg, argptr);
	va_end(argptr);

	trap_Print(text);
}

/*
==================
CheckCvars
==================
*/
void CheckCvars(void) {
	static int lastMod = -1;

	if(g_password.modificationCount != lastMod) {
		lastMod = g_password.modificationCount;
		if(*g_password.string && Q_stricmp(g_password.string, "none")) {
			trap_Cvar_Set("g_needpass", "1");
		} else {
			trap_Cvar_Set("g_needpass", "0");
		}
	}
}

/*
=============
G_RunThink

Runs thinking code for this frame if necessary
=============
*/
void G_RunThink(gentity_t* ent) {
	int thinktime;

	thinktime = ent->nextthink;
	if(thinktime <= 0) {
		return;
	}
	if(thinktime > level.time) {
		return;
	}

	ent->nextthink = 0;
	if(!ent->think) {
		G_Error("NULL ent->think");
	}
	ent->think(ent);
}

/*
================
G_RunFrame

Advances the non-player objects in the world
================
*/
void G_RunFrame(int levelTime) {
	int i;
	gentity_t* ent;

	// if we are waiting for the level to restart, do nothing
	if(level.restarted) {
		return;
	}

	level.framenum++;
	level.previousTime = level.time;
	level.time = levelTime;

	// get any cvar changes
	G_UpdateCvars();

	JS_GameRunFrame(level.time, level.framenum);

	//
	// go through all allocated objects
	//
	ent = &g_entities[0];
	for(i = 0; i < level.num_entities; i++, ent++) {
		if(!ent->inuse) {
			continue;
		}

		// clear events that are too old
		if(level.time - ent->eventTime > EVENT_VALID_MSEC) {
			if(ent->s.event) {
				ent->s.event = 0;  // &= EV_EVENT_BITS;
				if(ent->client) ent->client->ps.externalEvent = 0;
			}
			if(ent->freeAfterEvent) {
				// tempEntities or dropped items completely go away after their event
				G_FreeEntity(ent);
				continue;
			} else if(ent->unlinkAfterEvent) {
				// items that will respawn will hide themselves after their pickup event
				ent->unlinkAfterEvent = false;
				trap_UnlinkEntity(ent);
			}
		}

		// temporary entities don't think
		if(ent->freeAfterEvent) {
			continue;
		}

		if(!ent->r.linked && ent->neverFree) {
			continue;
		}

		if(ent->s.eType == ET_MISSILE) {
			G_RunMissile(ent);
			continue;
		}

		if(ent->s.eType == ET_ITEM || ent->physicsObject) {
			G_RunItem(ent);
			continue;
		}

		if(ent->s.eType == ET_MOVER) {
			G_RunMover(ent);
			continue;
		}

		if(ent->s.eType == ET_PHYSICS) {
			G_RunPhysics(ent);
			continue;
		}

		if(ent->s.eType == ET_RAGDOLL) {
			// movement is done by G_RunRagdolls after all bones have been run,
			// but the master still thinks (removes the ragdoll after its lifetime)
			G_RunThink(ent);
			continue;
		}

		if(i < MAX_CLIENTS) {
			G_RunClient(ent);
			continue;
		}

		G_RunThink(ent);
	}

	// ragdoll master entities follow their main bone
	G_RunRagdolls();

	// perform final fixups on the players
	ent = &g_entities[0];
	for(i = 0; i < level.maxclients; i++, ent++) {
		if(ent->inuse) {
			ClientEndFrame(ent);
		}
	}

	// for tracking changes
	CheckCvars();

	if(g_listEntity.integer) {
		for(i = 0; i < MAX_GENTITIES; i++) {
			G_Printf("%4i: %s\n", i, g_entities[i].classname);
		}
		trap_Cvar_Set("g_listEntity", "0");
	}
}
