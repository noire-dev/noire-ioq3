/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
//

#include "g_local.h"

// g_client.c -- client functions that don't happen every frame

static vec3_t playerMins = {-15, -15, -24};
static vec3_t playerMaxs = {15, 15, 48};

/*QUAKED info_player_deathmatch (1 0 1) (-16 -16 -24) (16 16 32) initial
potential spawning position for deathmatch games.
The first time a player enters the game, they will be at an 'initial' spot.
Targets will be fired when someone spawns in on them.
"nobots" will prevent bots from using this spot.
"nohumans" will prevent non-bots from using this spot.
*/
void SP_info_player_deathmatch(gentity_t* ent) {
	int i;

	G_SpawnInt("nobots", "0", &i);
	if(i) {
		ent->flags |= FL_NO_BOTS;
	}
	G_SpawnInt("nohumans", "0", &i);
	if(i) {
		ent->flags |= FL_NO_HUMANS;
	}
}

/*QUAKED info_player_start (1 0 0) (-16 -16 -24) (16 16 32)
equivalent to info_player_deathmatch
*/
void SP_info_player_start(gentity_t* ent) {
	ent->classname = "info_player_deathmatch";
	SP_info_player_deathmatch(ent);
}

/*
=======================================================================

  SelectSpawnPoint

=======================================================================
*/

/*
================
SpotWouldTelefrag

================
*/
bool SpotWouldTelefrag(gentity_t* spot) {
	int i, num;
	int touch[MAX_GENTITIES];
	gentity_t* hit;
	vec3_t mins, maxs;

	VectorAdd(spot->s.origin, playerMins, mins);
	VectorAdd(spot->s.origin, playerMaxs, maxs);
	num = trap_EntitiesInBox(mins, maxs, touch, MAX_GENTITIES);

	for(i = 0; i < num; i++) {
		hit = &g_entities[touch[i]];
		// if ( hit->client && hit->client->ps.stats[STAT_HEALTH] > 0 ) {
		if(hit->client) {
			return true;
		}
	}

	return false;
}

#define MAX_SPAWN_POINTS 128

/*
===========
SelectRandomFurthestSpawnPoint

Chooses a player start, deathmatch start, etc
============
*/
gentity_t* SelectRandomFurthestSpawnPoint(vec3_t avoidPoint, vec3_t origin, vec3_t angles, bool isbot) {
	gentity_t* spot;
	vec3_t delta;
	float dist;
	float list_dist[MAX_SPAWN_POINTS];
	gentity_t* list_spot[MAX_SPAWN_POINTS];
	int numSpots, rnd, i, j;

	numSpots = 0;
	spot = NULL;

	while((spot = G_Find(spot, FOFS(classname), "info_player_deathmatch")) != NULL) {
		if(SpotWouldTelefrag(spot)) continue;

		if(((spot->flags & FL_NO_BOTS) && isbot) || ((spot->flags & FL_NO_HUMANS) && !isbot)) {
			// spot is not for this human/bot player
			continue;
		}

		VectorSubtract(spot->s.origin, avoidPoint, delta);
		dist = VectorLength(delta);

		for(i = 0; i < numSpots; i++) {
			if(dist > list_dist[i]) {
				if(numSpots >= MAX_SPAWN_POINTS) numSpots = MAX_SPAWN_POINTS - 1;

				for(j = numSpots; j > i; j--) {
					list_dist[j] = list_dist[j - 1];
					list_spot[j] = list_spot[j - 1];
				}

				list_dist[i] = dist;
				list_spot[i] = spot;

				numSpots++;
				break;
			}
		}

		if(i >= numSpots && numSpots < MAX_SPAWN_POINTS) {
			list_dist[numSpots] = dist;
			list_spot[numSpots] = spot;
			numSpots++;
		}
	}

	if(!numSpots) {
		spot = G_Find(NULL, FOFS(classname), "info_player_deathmatch");

		if(!spot) G_Error("Couldn't find a spawn point");

		VectorCopy(spot->s.origin, origin);
		origin[2] += 9;
		VectorCopy(spot->s.angles, angles);
		return spot;
	}

	// select a random spot from the spawn points furthest away
	rnd = random() * (numSpots / 2);

	VectorCopy(list_spot[rnd]->s.origin, origin);
	origin[2] += 9;
	VectorCopy(list_spot[rnd]->s.angles, angles);

	return list_spot[rnd];
}

/*
===========
SelectSpawnPoint

Chooses a player start, deathmatch start, etc
============
*/
gentity_t* SelectSpawnPoint(vec3_t avoidPoint, vec3_t origin, vec3_t angles, bool isbot) { return SelectRandomFurthestSpawnPoint(avoidPoint, origin, angles, isbot); }

/*
=======================================================================

BODYQUE

=======================================================================
*/

/*
===============
InitBodyQue
===============
*/
void InitBodyQue(void) {
	int i;
	gentity_t* ent;

	level.bodyQueIndex = 0;
	for(i = 0; i < BODY_QUEUE_SIZE; i++) {
		ent = G_Spawn();
		ent->classname = "bodyque";
		ent->neverFree = true;
		level.bodyQue[i] = ent;
	}
}

/*
=============
BodySink

After sitting around for five seconds, fall into the ground and disappear
=============
*/
void BodySink(gentity_t* ent) {
	if(level.time - ent->timestamp > 6500) {
		// the body ques are never actually freed, they are just unlinked
		trap_UnlinkEntity(ent);
		ent->physicsObject = false;
		return;
	}
	ent->nextthink = level.time + 100;
	ent->s.pos.trBase[2] -= 1;
}

/*
=============
CopyToBodyQue

A player is respawning, so make an entity that looks
just like the existing corpse to leave behind.
=============
*/
void CopyToBodyQue(gentity_t* ent) {
	gentity_t* body;
	int contents;

	trap_UnlinkEntity(ent);

	// if client is in a nodrop area, don't leave the body
	contents = trap_PointContents(ent->s.origin, -1);
	if(contents & CONTENTS_NODROP) {
		return;
	}

	// grab a body que and cycle to the next one
	body = level.bodyQue[level.bodyQueIndex];
	level.bodyQueIndex = (level.bodyQueIndex + 1) % BODY_QUEUE_SIZE;

	body->s = ent->s;
	body->s.eFlags = EF_DEAD;  // clear
	body->s.loopSound = 0;     // clear lava burning
	body->s.number = body - g_entities;
	body->timestamp = level.time;
	body->physicsObject = true;
	body->physicsBounce = 0;  // don't bounce
	if(body->s.groundEntityNum == ENTITYNUM_NONE) {
		body->s.pos.trType = TR_GRAVITY;
		body->s.pos.trTime = level.time;
		VectorCopy(ent->client->ps.velocity, body->s.pos.trDelta);
	} else {
		body->s.pos.trType = TR_STATIONARY;
	}
	body->s.event = 0;

	// IQM full-body death clips are non-looping; keep the selected action on the corpse.
	body->s.torsoAnim = body->s.legsAnim;

	body->r.svFlags = ent->r.svFlags;
	VectorCopy(ent->r.mins, body->r.mins);
	VectorCopy(ent->r.maxs, body->r.maxs);
	VectorCopy(ent->r.absmin, body->r.absmin);
	VectorCopy(ent->r.absmax, body->r.absmax);

	body->clipmask = CONTENTS_SOLID | CONTENTS_PLAYERCLIP;
	body->r.contents = CONTENTS_CORPSE;
	body->r.ownerNum = ent->s.number;

	body->nextthink = level.time + 5000;
	body->think = BodySink;

	body->die = body_die;
	body->takedamage = true;

	VectorCopy(body->s.pos.trBase, body->r.currentOrigin);
	trap_LinkEntity(body);
}

//======================================================================

/*
==================
SetClientViewAngle

==================
*/
void SetClientViewAngle(gentity_t* ent, vec3_t angle) {
	int i;

	// set the delta angle
	for(i = 0; i < 2; i++) {
		int cmdAngle;

		cmdAngle = ANGLE2SHORT(angle[i]);
		ent->client->ps.delta_angles[i] = cmdAngle - ent->client->pers.cmd.angles[i];
	}
	VectorCopy(angle, ent->s.angles);
	VectorCopy(ent->s.angles, ent->client->ps.viewangles);
}

/*
================
ClientRespawn
================
*/
void ClientRespawn(gentity_t* ent) {
	CopyToBodyQue(ent);
	ClientSpawn(ent);
}

/*
===========
ClientCleanName
============
*/
static void ClientCleanName(const char* in, char* out, int outSize) {
	int outpos = 0, colorlessLen = 0, spaces = 0;

	// discard leading spaces
	for(; *in == ' '; in++);

	for(; *in && outpos < outSize - 1; in++) {
		out[outpos] = *in;

		if(*in == ' ') {
			// don't allow too many consecutive spaces
			if(spaces > 2) continue;

			spaces++;
		} else {
			spaces = 0;
			colorlessLen++;
		}

		outpos++;
	}

	out[outpos] = '\0';

	// don't allow empty names
	if(*out == '\0' || colorlessLen == 0) Q_strncpyz(out, "UnnamedPlayer", outSize);
}

/*
===========
ClientUserInfoChanged

Called from ClientConnect when the player first connects and
directly by the server system when the player updates a userinfo variable.

The game can override any of the settings and call trap_SetUserinfo
if desired.
============
*/
void ClientUserinfoChanged(int clientNum) {
	gentity_t* ent;
	char* s;
	char model[MAX_QPATH];
	char oldname[MAX_STRING_CHARS];
	gclient_t* client;
	char userinfo[MAX_INFO_STRING];
	char physR[16], physG[16], physB[16];

	ent = g_entities + clientNum;
	client = ent->client;

	trap_GetUserinfo(clientNum, userinfo, sizeof(userinfo));

	// check for malformed or illegal info strings
	if(!Info_Validate(userinfo)) {
		strcpy(userinfo, "\\name\\badinfo");
		// don't keep those clients and userinfo
		trap_DropClient(clientNum, "Invalid userinfo");
	}

	// set name
	Q_strncpyz(oldname, client->pers.netname, sizeof(oldname));
	s = Info_ValueForKey(userinfo, "name");
	ClientCleanName(s, client->pers.netname, sizeof(client->pers.netname));

	if(client->pers.connected == CON_CONNECTED) {
		if(strcmp(oldname, client->pers.netname)) {
			trap_SendServerCommand(-1, va("print \"%s" S_COLOR_WHITE " renamed to %s\n\"", oldname, client->pers.netname));
		}
	}

	// set model
	Q_strncpyz(model, Info_ValueForKey(userinfo, "model"), sizeof(model));

	// colors
	strcpy(physR, Info_ValueForKey(userinfo, "physR"));
	strcpy(physG, Info_ValueForKey(userinfo, "physG"));
	strcpy(physB, Info_ValueForKey(userinfo, "physB"));

	// send over a subset of the userinfo keys so other clients can
	// print scoreboards, display models, and play custom sounds
	s = va("n\\%s\\model\\%s\\pr\\%s\\pg\\%s\\pb\\%s\\ge\\%d", client->pers.netname, model, physR, physG, physB, ent->grabbedEntity ? ent->grabbedEntity->s.number : 0);

	trap_SetConfigstring(CS_PLAYERS + clientNum, s);
}

/*
===========
ClientUpdateGrabbedConfigstring

Rebuilds the CS_PLAYERS configstring for the given client so that the
grabbed entity number is broadcast to every connected client, mirroring
how physR/physG/physB are networked. Called whenever the physgun or
gravity gun grab state changes on the server.
===========
*/
void ClientUpdateGrabbedConfigstring(gentity_t* ent) {
	int clientNum;
	gclient_t* client;
	char* s;
	char model[MAX_QPATH];
	char userinfo[MAX_INFO_STRING];
	char physR[16], physG[16], physB[16];
	int grabbedEntityNum;

	if(!ent || !ent->client) return;
	if(ent->client->pers.connected != CON_CONNECTED) return;

	clientNum = ent - g_entities;
	client = ent->client;

	trap_GetUserinfo(clientNum, userinfo, sizeof(userinfo));

	Q_strncpyz(model, Info_ValueForKey(userinfo, "model"), sizeof(model));
	Q_strncpyz(physR, Info_ValueForKey(userinfo, "physR"), sizeof(physR));
	Q_strncpyz(physG, Info_ValueForKey(userinfo, "physG"), sizeof(physG));
	Q_strncpyz(physB, Info_ValueForKey(userinfo, "physB"), sizeof(physB));

	grabbedEntityNum = ent->grabbedEntity ? ent->grabbedEntity->s.number : 0;

	s = va("n\\%s\\model\\%s\\pr\\%s\\pg\\%s\\pb\\%s\\ge\\%d", client->pers.netname, model, physR, physG, physB, grabbedEntityNum);
	trap_SetConfigstring(CS_PLAYERS + clientNum, s);
}

/*
===========
ClientConnect

Called when a player begins connecting to the server.
Called again for every map change or tournement restart.

The session information will be valid after exit.

Return NULL if the client should be allowed, otherwise return
a string with the reason for denial.

Otherwise, the client will be sent the current gamestate
and will eventually get to ClientBegin.

firstTime will be true the very first time a client connects
to the server machine, but false on map changes and tournement
restarts.
============
*/
char* ClientConnect(int clientNum, bool firstTime, bool isBot) {
	char* value;
	gclient_t* client;
	char userinfo[MAX_INFO_STRING];
	gentity_t* ent;

	ent = &g_entities[clientNum];

	trap_GetUserinfo(clientNum, userinfo, sizeof(userinfo));

	value = Info_ValueForKey(userinfo, "ip");

	// we don't check password for bots and local client
	// NOTE: local client <-> "ip" "localhost"
	//   this means this client is not running in our current process
	if(!isBot && (strcmp(value, "localhost") != 0)) {
		// check for a password
		value = Info_ValueForKey(userinfo, "password");
		if(g_password.string[0] && Q_stricmp(g_password.string, "none") && strcmp(g_password.string, value) != 0) {
			return "Invalid password";
		}
	}
	// if a player reconnects quickly after a disconnect, the client disconnect may never be called, thus flag can get lost in the ether
	if(ent->inuse) {
		// so lets just fix up anything that should happen on a disconnect
		ClientDisconnect(clientNum);
	}
	// they can connect
	ent->client = level.clients + clientNum;
	client = ent->client;

	memset(client, 0, sizeof(*client));

	client->pers.connected = CON_CONNECTING;

	// check for local client
	value = Info_ValueForKey(userinfo, "ip");
	if(!strcmp(value, "localhost")) {
		client->pers.localClient = true;
	}

	if(isBot) {
		ent->r.svFlags |= SVF_BOT;
		ent->inuse = true;
		if(!G_BotConnect(clientNum, !firstTime)) {
			return "BotConnectfailed";
		}
	}

	// get and distribute relevant parameters
	ClientUserinfoChanged(clientNum);

	// don't do the "xxx connected" messages if they were caried over from previous level
	if(firstTime) {
		trap_SendServerCommand(-1, va("print \"%s" S_COLOR_WHITE " connected\n\"", client->pers.netname));
	}

	return NULL;
}

/*
===========
ClientBegin

called when a client has finished connecting, and is ready
to be placed into the level.  This will happen every level load,
and on transition between teams, but doesn't happen on respawns
============
*/
void ClientBegin(int clientNum) {
	gentity_t* ent;
	gclient_t* client;
	int flags;

	ent = g_entities + clientNum;

	client = level.clients + clientNum;

	if(ent->r.linked) {
		trap_UnlinkEntity(ent);
	}
	G_InitGentity(ent);
	ent->touch = 0;
	ent->pain = 0;
	ent->client = client;

	client->pers.connected = CON_CONNECTED;

	// save eflags around this, because changing teams will
	// cause this to happen with a valid entity, and we
	// want to make sure the teleport bit is set right
	// so the viewpoint doesn't interpolate through the
	// world to the new position
	flags = client->ps.eFlags;
	memset(&client->ps, 0, sizeof(client->ps));
	client->ps.eFlags = flags;

	// locate ent at a spawn point
	ClientSpawn(ent);

	trap_SendServerCommand(-1, va("print \"%s" S_COLOR_WHITE " entered the game\n\"", client->pers.netname));
}

/*
===========
ClientSpawn

Called every time a client is placed fresh in the world:
after the first ClientBegin, and after each respawn
Initializes all non-persistant parts of playerState
============
*/
void ClientSpawn(gentity_t* ent) {
	int index;
	vec3_t spawn_origin, spawn_angles;
	gclient_t* client;
	int i;
	clientPersistant_t saved;
	int persistant[MAX_PERSISTANT];
	gentity_t* spawnPoint;
	int flags;
	int savedPing;
	int eventSequence;
	char userinfo[MAX_INFO_STRING];

	index = ent - g_entities;
	client = ent->client;

	VectorClear(spawn_origin);

	spawnPoint = SelectSpawnPoint(client->ps.origin, spawn_origin, spawn_angles, !!(ent->r.svFlags & SVF_BOT));

	// toggle the teleport bit so the client knows to not lerp
	flags = ent->client->ps.eFlags & EF_TELEPORT_BIT;
	flags ^= EF_TELEPORT_BIT;

	// clear everything but the persistant data
	saved = client->pers;
	savedPing = client->ps.ping;
	for(i = 0; i < MAX_PERSISTANT; i++) {
		persistant[i] = client->ps.persistant[i];
	}
	eventSequence = client->ps.eventSequence;

	Com_Memset(client, 0, sizeof(*client));

	client->pers = saved;
	client->ps.ping = savedPing;

	for(i = 0; i < MAX_PERSISTANT; i++) {
		client->ps.persistant[i] = persistant[i];
	}
	client->ps.eventSequence = eventSequence;
	// increment the spawncount so the client will detect the respawn
	client->ps.persistant[PERS_SPAWN_COUNT]++;

	client->airOutTime = level.time + 12000;

	trap_GetUserinfo(index, userinfo, sizeof(userinfo));

	// clear entity values
	client->ps.eFlags = flags;

	ent->s.groundEntityNum = ENTITYNUM_NONE;
	ent->client = &level.clients[index];
	ent->takedamage = true;
	ent->inuse = true;
	ent->classname = "player";
	ent->r.contents = CONTENTS_BODY;
	ent->clipmask = MASK_PLAYERSOLID;
	ent->die = player_die;
	ent->waterlevel = 0;
	ent->watertype = 0;
	ent->flags = 0;

	VectorCopy(playerMins, ent->r.mins);
	VectorCopy(playerMaxs, ent->r.maxs);

	client->ps.clientNum = index;

	ent->health = client->ps.stats[STAT_HEALTH] = 100;

	G_SetOrigin(ent, spawn_origin);
	VectorCopy(spawn_origin, client->ps.origin);

	// the respawned flag will be cleared after the attack and jump keys come up
	client->ps.pm_flags |= PMF_RESPAWNED;

	trap_GetUsercmd(client - level.clients, &ent->client->pers.cmd);
	SetClientViewAngle(ent, spawn_angles);

	G_SendSpawnSwepWeapons(ent);

	// don't allow full run speed for a bit
	client->ps.pm_flags |= PMF_TIME_KNOCKBACK;
	client->ps.pm_time = 100;

	client->respawnTime = level.time;
	client->inactivityTime = level.time + g_inactivity.integer * 1000;

	// set default animations
	client->ps.torsoAnim = AM_IDLE;
	client->ps.legsAnim = AM_IDLE;

	G_KillBox(ent);
	// force the base weapon up
	client->ps.weapon = 0;
	client->ps.weaponstate = WEAPON_READY;
	for(i = 1; i < jsd_weaponCount; i++) {
		ent->swep_list[i] = WS_NONE;
		ent->swep_ammo[i] = 0;
	}

	G_UseTargets(spawnPoint, ent);

	// positively link the client, even if the command times are weird
	VectorCopy(ent->client->ps.origin, ent->r.currentOrigin);

	G_TempEntity(ent->client->ps.origin, EV_PARTICLE, PP_TELEPORT_IN);

	trap_LinkEntity(ent);

	// run a client frame to drop exactly to the floor,
	// initialize animations and other things
	client->ps.commandTime = level.time - 100;
	ent->client->pers.cmd.serverTime = level.time;
	ClientThink(ent - g_entities);
	ClientEndFrame(ent);

	// clear entity state values
	BG_PlayerStateToEntityState(&client->ps, &ent->s, true);
}

/*
===========
ClientDisconnect

Called when a player drops from the server.
Will not be called between levels.

This should NOT be called directly by any game logic,
call trap_DropClient(), which will call this and do
server system housekeeping.
============
*/
void ClientDisconnect(int clientNum) {
	gentity_t* ent;

	ent = g_entities + clientNum;
	if(!ent->client || ent->client->pers.connected == CON_DISCONNECTED) {
		return;
	}

	JS_ClearJSSpawnedNPC(clientNum);
	// send effect if they were completely connected
	if(ent->client->pers.connected == CON_CONNECTED) {
		G_TempEntity(ent->client->ps.origin, EV_PARTICLE, PP_TELEPORT_OUT);
		TossClientItems(ent);
	}

	trap_UnlinkEntity(ent);
	ent->s.modelindex = 0;
	ent->inuse = false;
	ent->classname = "disconnected";
	ent->client->pers.connected = CON_DISCONNECTED;

	trap_SetConfigstring(CS_PLAYERS + clientNum, "");

	if(ent->r.svFlags & SVF_BOT) {
		BotAIShutdownClient(clientNum, false);
	}
}
