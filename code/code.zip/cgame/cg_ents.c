/*
===========================================================================
Copyright (C) 1999-2005 Id Software, Inc.

This file is part of Quake III Arena source code.

Quake III Arena source code is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

Quake III Arena source code is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Quake III Arena source code; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
===========================================================================
*/
//
// cg_ents.c -- present snapshot entities, happens every single frame

#include "cg_local.h"
#include <math.h>

/*
======================
CG_PositionRotatedEntityOnTag

Modifies the entities position and axis by the given
tag location
======================
*/
void CG_PositionRotatedEntityOnTag(refEntity_t* entity, const refEntity_t* parent, qhandle_t parentModel, char* tagName) {
	int i;
	orientation_t lerped;
	vec3_t tempAxis[3];

	// AxisClear( entity->axis );
	//  lerp the tag
	trap_CM_LerpTag(&lerped, parentModel, parent->oldframe, parent->frame, 1.0 - parent->backlerp, tagName);

	// FIXME: allow origin offsets along tag?
	VectorCopy(parent->origin, entity->origin);
	for(i = 0; i < 3; i++) {
		VectorMA(entity->origin, lerped.origin[i], parent->axis[i], entity->origin);
	}

	// had to cast away the const to avoid compiler problems...
	MatrixMultiply(entity->axis, lerped.axis, tempAxis);
	MatrixMultiply(tempAxis, ((refEntity_t*)parent)->axis, entity->axis);
}

/*
==========================================================================

FUNCTIONS CALLED EACH FRAME

==========================================================================
*/

/*
======================
CG_SetEntitySoundPosition

Also called by event processing code
======================
*/
void CG_SetEntitySoundPosition(centity_t* cent) {
	if(cent->currentState.solid == SOLID_BMODEL) {
		vec3_t origin;
		float* v;

		v = cgs.inlineModelMidpoints[cent->currentState.modelindex];
		VectorAdd(cent->lerpOrigin, v, origin);
		trap_S_UpdateEntityPosition(cent->currentState.number, origin);
	} else {
		trap_S_UpdateEntityPosition(cent->currentState.number, cent->lerpOrigin);
	}
}

/*
==================
CG_EntityEffects

Add continuous entity effects, like local entity emission and lighting
==================
*/
static void CG_EntityEffects(centity_t* cent) {
	// update sound origins
	CG_SetEntitySoundPosition(cent);

	// add loop sound
	if(cent->currentState.loopSound) {
		if(cent->currentState.eType != ET_SPEAKER) {
			trap_S_AddLoopingSound(cent->currentState.number, cent->lerpOrigin, vec3_origin, cgs.gameSounds[cent->currentState.loopSound]);
		} else {
			trap_S_AddRealLoopingSound(cent->currentState.number, cent->lerpOrigin, vec3_origin, cgs.gameSounds[cent->currentState.loopSound]);
		}
	}

	// constant light glow
	if(cent->currentState.constantLight) {
		int cl;
		float i, r, g, b;

		cl = cent->currentState.constantLight;
		r = (float)(cl & 0xFF) / 255.0;
		g = (float)((cl >> 8) & 0xFF) / 255.0;
		b = (float)((cl >> 16) & 0xFF) / 255.0;
		i = (float)((cl >> 24) & 0xFF) * 4.0;
		trap_R_AddLightToScene(cent->lerpOrigin, i, 1.00f, r, g, b, 0);
	}
}

/*
==================
CG_General
==================
*/
static void CG_General(centity_t* cent) {
	refEntity_t ent;
	entityState_t* s1;

	s1 = &cent->currentState;

	// if set to invisible, skip
	if(!s1->modelindex) {
		return;
	}

	memset(&ent, 0, sizeof(ent));

	// set frame

	ent.frame = s1->frame;
	ent.oldframe = ent.frame;
	ent.backlerp = 0;

	VectorCopy(cent->lerpOrigin, ent.origin);
	VectorCopy(cent->lerpOrigin, ent.oldorigin);

	ent.hModel = cgs.gameModels[s1->modelindex];

	// player model
	if(s1->number == cg.snap->ps.clientNum) {
		ent.renderfx |= RF_THIRD_PERSON;  // only draw from mirrors
	}

	// convert angles to axis
	AnglesToAxis(cent->lerpAngles, ent.axis);

	// add to refresh list
	trap_R_AddRefEntityToScene(&ent);
}

/*
 * Quaternion helpers for physics-entity rendering.
 *
 * Physics orientations arrive as Euler angles in snapshots. Interpolating
 * pitch/yaw/roll independently is not equivalent to interpolating a 3D
 * orientation and can visibly jump when the Euler representation changes
 * branch.
 * Convert the rendered endpoint axes to quaternions, slerp, then rebuild the
 * render axis. This affects presentation only; Bullet's simulation is untouched.
 */
static void CG_AxisToQuat(vec3_t axis[3], float q[4]) {
	/* AnglesToAxis stores each local basis vector in axis[local][world]. */
	float m00 = axis[0][0], m01 = axis[1][0], m02 = axis[2][0];
	float m10 = axis[0][1], m11 = axis[1][1], m12 = axis[2][1];
	float m20 = axis[0][2], m21 = axis[1][2], m22 = axis[2][2];
	float trace = m00 + m11 + m22;
	float scale;

	if(trace > 0.0f) {
		scale = sqrtf(trace + 1.0f) * 2.0f;
		q[3] = 0.25f * scale;
		q[0] = (m21 - m12) / scale;
		q[1] = (m02 - m20) / scale;
		q[2] = (m10 - m01) / scale;
	} else if(m00 > m11 && m00 > m22) {
		scale = sqrtf(1.0f + m00 - m11 - m22) * 2.0f;
		q[3] = (m21 - m12) / scale;
		q[0] = 0.25f * scale;
		q[1] = (m01 + m10) / scale;
		q[2] = (m02 + m20) / scale;
	} else if(m11 > m22) {
		scale = sqrtf(1.0f + m11 - m00 - m22) * 2.0f;
		q[3] = (m02 - m20) / scale;
		q[0] = (m01 + m10) / scale;
		q[1] = 0.25f * scale;
		q[2] = (m12 + m21) / scale;
	} else {
		scale = sqrtf(1.0f + m22 - m00 - m11) * 2.0f;
		q[3] = (m10 - m01) / scale;
		q[0] = (m02 + m20) / scale;
		q[1] = (m12 + m21) / scale;
		q[2] = 0.25f * scale;
	}
}

static void CG_QuatToAxis(const float q[4], vec3_t axis[3]) {
	float x = q[0], y = q[1], z = q[2], w = q[3];
	float xx = x * x, yy = y * y, zz = z * z;
	float xy = x * y, xz = x * z, yz = y * z;
	float xw = x * w, yw = y * w, zw = z * w;

	/* Build the rotation matrix and transpose it into Quake's axis layout. */
	axis[0][0] = 1.0f - 2.0f * (yy + zz);
	axis[0][1] = 2.0f * (xy + zw);
	axis[0][2] = 2.0f * (xz - yw);
	axis[1][0] = 2.0f * (xy - zw);
	axis[1][1] = 1.0f - 2.0f * (xx + zz);
	axis[1][2] = 2.0f * (yz + xw);
	axis[2][0] = 2.0f * (xz + yw);
	axis[2][1] = 2.0f * (yz - xw);
	axis[2][2] = 1.0f - 2.0f * (xx + yy);
}

static void CG_SlerpQuat(const float from[4], const float to[4], float frac, float out[4]) {
	float target[4], dot = 0.0f;
	float fromScale, toScale;
	int i;

	for(i = 0; i < 4; ++i) {
		target[i] = to[i];
		dot += from[i] * target[i];
	}

	/* q and -q describe the same rotation; choose the shorter arc. */
	if(dot < 0.0f) {
		dot = -dot;
		for(i = 0; i < 4; ++i) target[i] = -target[i];
	}

	if(dot > 0.9995f) {
		float length;
		for(i = 0; i < 4; ++i) out[i] = from[i] + frac * (target[i] - from[i]);
		length = sqrtf(out[0] * out[0] + out[1] * out[1] + out[2] * out[2] + out[3] * out[3]);
		if(length > 1e-8f) {
			for(i = 0; i < 4; ++i) out[i] /= length;
		} else {
			for(i = 0; i < 4; ++i) out[i] = from[i];
		}
		return;
	}

	if(dot > 1.0f) dot = 1.0f;
	{
		float theta = acosf(dot);
		float sinTheta = sinf(theta);
		fromScale = sinf((1.0f - frac) * theta) / sinTheta;
		toScale = sinf(frac * theta) / sinTheta;
	}
	for(i = 0; i < 4; ++i) out[i] = fromScale * from[i] + toScale * target[i];
}

/*
==================
CG_Physics
==================
*/
static void CG_Physics(centity_t* cent) {
	refEntity_t ent;
	entityState_t* s1;

	s1 = &cent->currentState;

	// if set to invisible, skip
	if(!s1->modelindex) return;

	memset(&ent, 0, sizeof(ent));

	// set frame
	ent.frame = s1->frame;
	ent.oldframe = ent.frame;
	ent.backlerp = 0;

	VectorCopy(cent->lerpOrigin, ent.origin);
	VectorCopy(cent->lerpOrigin, ent.oldorigin);

	ent.hModel = cgs.gameModels[s1->modelindex];

	// Interpolate physics orientation as a quaternion, not as three Euler angles.
	// The latter can jump when QuatToAngles changes Euler branch near a steep roll.
	if(cent->interpolate && cent->currentState.pos.trType == TR_INTERPOLATE && cg.nextSnap) {
		vec3_t currentAngles, nextAngles;
		vec3_t currentAxis[3], nextAxis[3];
		float currentQuat[4], nextQuat[4], lerpedQuat[4];

		BG_EvaluateTrajectory(&cent->currentState.apos, cg.snap->serverTime, currentAngles);
		BG_EvaluateTrajectory(&cent->nextState.apos, cg.nextSnap->serverTime, nextAngles);
		AnglesToAxis(currentAngles, currentAxis);
		AnglesToAxis(nextAngles, nextAxis);
		CG_AxisToQuat(currentAxis, currentQuat);
		CG_AxisToQuat(nextAxis, nextQuat);
		CG_SlerpQuat(currentQuat, nextQuat, cg.frameInterpolation, lerpedQuat);
		CG_QuatToAxis(lerpedQuat, ent.axis);
	} else {
		AnglesToAxis(cent->lerpAngles, ent.axis);
	}

	// add to refresh list
	trap_R_AddRefEntityToScene(&ent);

	{
		int grabbingClient = -1;
		int k;
		for(k = 0; k < cgs.maxclients; k++) {
			if(cgs.clientinfo[k].infoValid && cgs.clientinfo[k].grabbedEntityNum == (int)s1->number && cgs.clientinfo[k].grabbedEntityNum > 0) {
				grabbingClient = k;
				break;
			}
		}
		if(grabbingClient >= 0) {
			refEntity_t outline;
			clientInfo_t* gci = &cgs.clientinfo[grabbingClient];

			outline = ent;
			outline.customShader = trap_R_RegisterShader("outline");
			outline.shaderRGBA[0] = gci->physR;
			outline.shaderRGBA[1] = gci->physG;
			outline.shaderRGBA[2] = gci->physB;
			outline.shaderRGBA[3] = 128;
			VectorScale(outline.axis[0], 1.032f, outline.axis[0]);
			VectorScale(outline.axis[1], 1.032f, outline.axis[1]);
			VectorScale(outline.axis[2], 1.032f, outline.axis[2]);
			outline.nonNormalizedAxes = true;
			trap_R_AddRefEntityToScene(&outline);
		}
	}
}

/*
==================
CG_Speaker

Speaker entities can automatically play sounds
==================
*/
static void CG_Speaker(centity_t* cent) {
	if(!cent->currentState.clientNum) {  // FIXME: use something other than clientNum...
		return;                          // not auto triggering
	}

	if(cg.time < cent->miscTime) {
		return;
	}

	trap_S_StartSound(NULL, cent->currentState.number, CHAN_ITEM, cgs.gameSounds[cent->currentState.eventParm]);

	//	ent->s.frame = ent->wait * 10;
	//	ent->s.clientNum = ent->random * 10;
	cent->miscTime = cg.time + cent->currentState.frame * 100 + cent->currentState.clientNum * 100 * crandom();
}

/*
==================
CG_Item
==================
*/
static void CG_Item(centity_t* cent) {
	refEntity_t ent;
	entityState_t* es;
	item_t* item;
	int msec;
	float scale;
	weaponInfo_t* wi;

	es = &cent->currentState;
	if(es->modelindex >= jsd_itemCount) {
		CG_Error("Bad item index %i on entity", es->modelindex);
	}

	// if set to invisible, skip
	if(!es->modelindex || (es->eFlags & EF_NODRAW)) {
		return;
	}

	item = &jsd_item[es->modelindex];

	// items bob up and down continuously
	scale = 0.005 + cent->currentState.number * 0.00001;
	cent->lerpOrigin[2] += 4 + cos((cg.time + 1000) * scale) * 4;

	memset(&ent, 0, sizeof(ent));

	// autorotate at one of two speeds
	VectorCopy(cg.autoAngles, cent->lerpAngles);
	AxisCopy(cg.autoAxis, ent.axis);

	wi = NULL;
	// the weapons have their origin where they attatch to player
	// models, so we need to offset them or they will rotate
	// eccentricly
	if(item->giType == IT_WEAPON) {
		wi = &cg_weapons[item->giTag];
		cent->lerpOrigin[0] -= wi->weaponMidpoint[0] * ent.axis[0][0] + wi->weaponMidpoint[1] * ent.axis[1][0] + wi->weaponMidpoint[2] * ent.axis[2][0];
		cent->lerpOrigin[1] -= wi->weaponMidpoint[0] * ent.axis[0][1] + wi->weaponMidpoint[1] * ent.axis[1][1] + wi->weaponMidpoint[2] * ent.axis[2][1];
		cent->lerpOrigin[2] -= wi->weaponMidpoint[0] * ent.axis[0][2] + wi->weaponMidpoint[1] * ent.axis[1][2] + wi->weaponMidpoint[2] * ent.axis[2][2];

		cent->lerpOrigin[2] += 8;  // an extra height boost
	}

	ent.hModel = cg_items[es->modelindex].models;

	VectorCopy(cent->lerpOrigin, ent.origin);
	VectorCopy(cent->lerpOrigin, ent.oldorigin);

	ent.nonNormalizedAxes = false;

	// if just respawned, slowly scale up
	msec = cg.time - cent->miscTime;
	if(msec >= 0 && msec < ITEM_SCALEUP_TIME) {
		float frac = (float)msec / ITEM_SCALEUP_TIME;
		VectorScale(ent.axis[0], frac, ent.axis[0]);
		VectorScale(ent.axis[1], frac, ent.axis[1]);
		VectorScale(ent.axis[2], frac, ent.axis[2]);
		ent.nonNormalizedAxes = true;
	}

	// increase the size of the weapons when they are presented as items
	if(item->giType == IT_WEAPON) {
		VectorScale(ent.axis[0], 1.5, ent.axis[0]);
		VectorScale(ent.axis[1], 1.5, ent.axis[1]);
		VectorScale(ent.axis[2], 1.5, ent.axis[2]);
		ent.nonNormalizedAxes = true;
	}

	// add to refresh list
	trap_R_AddRefEntityToScene(&ent);
}

//============================================================================

/*
===============
CG_Missile
===============
*/
static void CG_Missile(centity_t* cent) {
	refEntity_t ent;
	entityState_t* s1;
	weaponFx_t* fx;

	s1 = &cent->currentState;
	if(s1->weapon >= jsd_weaponCount) {
		s1->weapon = 0;
	}
	fx = &jsd_weaponFx[s1->weapon];

	// calculate the axis
	VectorCopy(s1->angles, cent->lerpAngles);

	// add trails (no-op if trailCount is 0)
	CG_MissileTrail(cent);

	// data-driven missile light
	if(fx->missileLightRadius > 0.0f) {
		trap_R_AddLightToScene(cent->lerpOrigin, fx->missileLightRadius, 1.00f, fx->missileLightColor[0], fx->missileLightColor[1], fx->missileLightColor[2], 0);
	}

	// add missile sound (fully data-driven)
	if(fx->missileFlySoundHandle) {
		vec3_t velocity;
		BG_EvaluateTrajectoryDelta(&cent->currentState.pos, cg.time, velocity);
		trap_S_AddLoopingSound(cent->currentState.number, cent->lerpOrigin, velocity, fx->missileFlySoundHandle);
	}

	// create the render entity
	memset(&ent, 0, sizeof(ent));
	VectorCopy(cent->lerpOrigin, ent.origin);
	VectorCopy(cent->lerpOrigin, ent.oldorigin);

	// data-driven missile sprite takes precedence when set
	if(fx->missileSpriteHandle) {
		ent.reType = RT_SPRITE;
		ent.radius = 16;
		ent.rotation = 0;
		ent.customShader = fx->missileSpriteHandle;
		trap_R_AddRefEntityToScene(&ent);
		return;
	}

	// flicker between two skins
	ent.skinNum = cg.clientFrame & 1;
	ent.hModel = fx->missileModelHandle;
	ent.renderfx = fx->missileRenderfx;

	// convert direction of travel into axis
	if(VectorNormalize2(s1->pos.trDelta, ent.axis[0]) == 0) {
		ent.axis[0][2] = 1;
	}

	// spin as it moves
	if(s1->pos.trType != TR_STATIONARY) {
		RotateAroundDirection(ent.axis, cg.time / 4);
	} else {
		RotateAroundDirection(ent.axis, s1->time);
	}

	trap_R_AddRefEntityToScene(&ent);
}

/*
===============
CG_Mover
===============
*/
static void CG_Mover(centity_t* cent) {
	refEntity_t ent;
	entityState_t* s1;

	s1 = &cent->currentState;

	// create the render entity
	memset(&ent, 0, sizeof(ent));
	VectorCopy(cent->lerpOrigin, ent.origin);
	VectorCopy(cent->lerpOrigin, ent.oldorigin);
	AnglesToAxis(cent->lerpAngles, ent.axis);

	// flicker between two skins (FIXME?)
	ent.skinNum = (cg.time >> 6) & 1;

	// get the model, either as a bmodel or a modelindex
	if(s1->solid == SOLID_BMODEL) {
		ent.hModel = cgs.inlineDrawModel[s1->modelindex];
	} else {
		ent.hModel = cgs.gameModels[s1->modelindex];
	}

	// add to refresh list
	trap_R_AddRefEntityToScene(&ent);

	// add the secondary model
	if(s1->modelindex2) {
		ent.skinNum = 0;
		ent.hModel = cgs.gameModels[s1->modelindex2];
		trap_R_AddRefEntityToScene(&ent);
	}
}

/*
===============
CG_Portal
===============
*/
static void CG_Portal(centity_t* cent) {
	refEntity_t ent;
	entityState_t* s1;

	s1 = &cent->currentState;

	// create the render entity
	memset(&ent, 0, sizeof(ent));
	VectorCopy(cent->lerpOrigin, ent.origin);
	VectorCopy(s1->origin2, ent.oldorigin);
	ByteToDir(s1->eventParm, ent.axis[0]);
	PerpendicularVector(ent.axis[1], ent.axis[0]);

	// negating this tends to get the directions like they want
	// we really should have a camera roll value
	VectorSubtract(vec3_origin, ent.axis[1], ent.axis[1]);

	CrossProduct(ent.axis[0], ent.axis[1], ent.axis[2]);
	ent.reType = RT_PORTALSURFACE;
	ent.frame = s1->frame;                      // rotation speed
	ent.skinNum = s1->clientNum / 256.0 * 360;  // roll offset

	// add to refresh list
	trap_R_AddRefEntityToScene(&ent);
}

/*
================
CG_CreateRotationMatrix
================
*/
static void CG_CreateRotationMatrix(vec3_t angles, vec3_t matrix[3]) {
	AngleVectors(angles, matrix[0], matrix[1], matrix[2]);
	VectorInverse(matrix[1]);
}

/*
================
CG_TransposeMatrix
================
*/
static void CG_TransposeMatrix(vec3_t matrix[3], vec3_t transpose[3]) {
	int i, j;
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 3; j++) {
			transpose[i][j] = matrix[j][i];
		}
	}
}

/*
================
CG_RotatePoint
================
*/
static void CG_RotatePoint(vec3_t point, vec3_t matrix[3]) {
	vec3_t tvec;

	VectorCopy(point, tvec);
	point[0] = DotProduct(matrix[0], tvec);
	point[1] = DotProduct(matrix[1], tvec);
	point[2] = DotProduct(matrix[2], tvec);
}

/*
=========================
CG_AdjustPositionForMover

Also called by client movement prediction code
=========================
*/
void CG_AdjustPositionForMover(const vec3_t in, int moverNum, int fromTime, int toTime, vec3_t out, vec3_t angles_in, vec3_t angles_out) {
	centity_t* cent;
	vec3_t oldOrigin, origin, deltaOrigin;
	vec3_t oldAngles, angles, deltaAngles;
	vec3_t matrix[3], transpose[3];
	vec3_t org, org2, move2;

	if(moverNum <= 0 || moverNum >= ENTITYNUM_MAX_NORMAL) {
		VectorCopy(in, out);
		VectorCopy(angles_in, angles_out);
		return;
	}

	cent = &cg_entities[moverNum];
	if(cent->currentState.eType != ET_MOVER) {
		VectorCopy(in, out);
		VectorCopy(angles_in, angles_out);
		return;
	}

	BG_EvaluateTrajectory(&cent->currentState.pos, fromTime, oldOrigin);
	BG_EvaluateTrajectory(&cent->currentState.apos, fromTime, oldAngles);

	BG_EvaluateTrajectory(&cent->currentState.pos, toTime, origin);
	BG_EvaluateTrajectory(&cent->currentState.apos, toTime, angles);

	VectorSubtract(origin, oldOrigin, deltaOrigin);
	VectorSubtract(angles, oldAngles, deltaAngles);

	// origin change when on a rotating object
	CG_CreateRotationMatrix(deltaAngles, transpose);
	CG_TransposeMatrix(transpose, matrix);
	VectorSubtract(in, oldOrigin, org);
	VectorCopy(org, org2);
	CG_RotatePoint(org2, matrix);
	VectorSubtract(org2, org, move2);
	VectorAdd(deltaOrigin, move2, deltaOrigin);

	VectorAdd(in, deltaOrigin, out);
	VectorAdd(angles_in, deltaAngles, angles_out);
}

/*
=============================
CG_InterpolateEntityPosition
=============================
*/
static void CG_InterpolateEntityPosition(centity_t* cent) {
	vec3_t current, next;
	float f;

	// it would be an internal error to find an entity that interpolates without
	// a snapshot ahead of the current one
	if(cg.nextSnap == NULL) {
		CG_Error("CG_InterpoateEntityPosition: cg.nextSnap == NULL");
	}

	f = cg.frameInterpolation;

	// this will linearize a sine or parabolic curve, but it is important
	// to not extrapolate player positions if more recent data is available
	BG_EvaluateTrajectory(&cent->currentState.pos, cg.snap->serverTime, current);
	BG_EvaluateTrajectory(&cent->nextState.pos, cg.nextSnap->serverTime, next);

	cent->lerpOrigin[0] = current[0] + f * (next[0] - current[0]);
	cent->lerpOrigin[1] = current[1] + f * (next[1] - current[1]);
	cent->lerpOrigin[2] = current[2] + f * (next[2] - current[2]);

	BG_EvaluateTrajectory(&cent->currentState.apos, cg.snap->serverTime, current);
	BG_EvaluateTrajectory(&cent->nextState.apos, cg.nextSnap->serverTime, next);

	cent->lerpAngles[0] = LerpAngle(current[0], next[0], f);
	cent->lerpAngles[1] = LerpAngle(current[1], next[1], f);
	cent->lerpAngles[2] = LerpAngle(current[2], next[2], f);
}

/*
===============
CG_CalcEntityLerpPositions

===============
*/
static void CG_CalcEntityLerpPositions(centity_t* cent) {
	if(cent->interpolate && cent->currentState.pos.trType == TR_INTERPOLATE) {
		CG_InterpolateEntityPosition(cent);
		return;
	}

	// first see if we can interpolate between two snaps for
	// linear extrapolated clients
	if(cent->interpolate && cent->currentState.pos.trType == TR_LINEAR_STOP && cent->currentState.number < MAX_CLIENTS) {
		CG_InterpolateEntityPosition(cent);
		return;
	}

	// just use the current frame and evaluate as best we can
	BG_EvaluateTrajectory(&cent->currentState.pos, cg.time, cent->lerpOrigin);
	BG_EvaluateTrajectory(&cent->currentState.apos, cg.time, cent->lerpAngles);

	// adjust for riding a mover if it wasn't rolled into the predicted
	// player state
	if(cent != &cg.predictedPlayerEntity) {
		CG_AdjustPositionForMover(cent->lerpOrigin, cent->currentState.groundEntityNum, cg.snap->serverTime, cg.time, cent->lerpOrigin, cent->lerpAngles, cent->lerpAngles);
	}
}

/*
===============
CG_AddCEntity

===============
*/
static void CG_AddCEntity(centity_t* cent) {
	// event-only entities will have been dealt with already
	if(cent->currentState.eType >= ET_EVENTS) {
		return;
	}

	// calculate the current origin
	CG_CalcEntityLerpPositions(cent);

	// add automatic effects
	CG_EntityEffects(cent);

	switch(cent->currentState.eType) {
		default: CG_Error("Bad entity type: %i", cent->currentState.eType); break;
		case ET_INVISIBLE:
		case ET_TELEPORT_TRIGGER: break;
		case ET_GENERAL: CG_General(cent); break;
		case ET_PHYSICS: CG_Physics(cent); break;
		case ET_RAGDOLL: CG_Ragdoll(cent); break;
		case ET_PLAYER: CG_Player(cent); break;
		case ET_ITEM: CG_Item(cent); break;
		case ET_MISSILE: CG_Missile(cent); break;
		case ET_MOVER: CG_Mover(cent); break;
		case ET_PORTAL: CG_Portal(cent); break;
		case ET_SPEAKER: CG_Speaker(cent); break;
	}
}

/*
===============
CG_AddPacketEntities

===============
*/
void CG_AddPacketEntities(void) {
	int num;
	centity_t* cent;
	playerState_t* ps;

	// set cg.frameInterpolation
	if(cg.nextSnap) {
		int delta;

		delta = (cg.nextSnap->serverTime - cg.snap->serverTime);
		if(delta == 0) {
			cg.frameInterpolation = 0;
		} else {
			cg.frameInterpolation = (float)(cg.time - cg.snap->serverTime) / delta;
		}
	} else {
		cg.frameInterpolation = 0;  // actually, it should never be used, because
		                            // no entities should be marked as interpolating
	}

	// the auto-rotating items will all have the same axis
	cg.autoAngles[0] = 0;
	cg.autoAngles[1] = (cg.time & 2047) * 360 / 2048.0;
	cg.autoAngles[2] = 0;

	cg.autoAnglesFast[0] = 0;
	cg.autoAnglesFast[1] = (cg.time & 1023) * 360 / 1024.0f;
	cg.autoAnglesFast[2] = 0;

	AnglesToAxis(cg.autoAngles, cg.autoAxis);
	AnglesToAxis(cg.autoAnglesFast, cg.autoAxisFast);

	// generate and add the entity from the playerstate
	ps = &cg.predictedPlayerState;
	BG_PlayerStateToEntityState(ps, &cg.predictedPlayerEntity.currentState, false);
	CG_AddCEntity(&cg.predictedPlayerEntity);

	// lerp the non-predicted value for lightning gun origins
	CG_CalcEntityLerpPositions(&cg_entities[cg.snap->ps.clientNum]);

	// add each entity sent over by the server
	for(num = 0; num < cg.snap->numEntities; num++) {
		cent = &cg_entities[cg.snap->entities[num].number];
		CG_AddCEntity(cent);
	}
}
